import util
profile = util.Profile(util.CourseBulletin('courses.json'), 'profile3b.txt')
print('Quarters:', profile.quarters)
print('Min units:', profile.minUnits)
print('Max units:', profile.maxUnits)
print('Requests:')
for i, req in enumerate(profile.requests):
    print('  {}: {} in {} prereqs: {} weight: {}'.format(i, req.cids, req.quarters, req.prereqs, req.weight))