import copy
from util import CSP, get_or_variable, CourseBulletin, Profile
from typing import Dict, List, Tuple
import collections

# COMPLETE FIXED create_sum_variable implementation
def create_sum_variable(csp: CSP, name: str, variables: List[Tuple], upperBound: int) -> str:
    """
    Given a list of variables with non-negative integer domains,
    create a new variable with name |name| whose domain is [0, upperBound]
    and add factors to the CSP so that |name| is equal to the sum of all
    variables in |variables|.
    
    This uses auxiliary variables to build a chain: sum_0, sum_1, ..., sum_n
    where sum_i = variables[0] + ... + variables[i]
    """
    
    # Use get_or_variable to avoid "Variable already exists" error
    get_or_variable(csp, name, list(range(upperBound + 1)))

    # Handle empty list: sum must be 0
    if not variables:
        csp.add_unary_factor(name, lambda val: 1.0 if val == 0 else 0.0)
        return name

    # Handle single variable: direct equality
    if len(variables) == 1:
        csp.add_binary_factor(variables[0], name, lambda a, b: 1.0 if a == b else 0.0)
        return name

    # Build chain of auxiliary sum variables
    # sum_i represents the sum of variables[0] through variables[i]

    for i in range(len(variables)):
        if i == 0:
            # First auxiliary variable equals first input variable
            sum_var_i = get_or_variable(csp, (name, 'sum', 0),
                                        list(range(upperBound + 1)))
            csp.add_binary_factor(variables[0], sum_var_i,
                                lambda a, b: 1.0 if a == b else 0.0)
        else:
            # sum_i = sum_{i-1} + variables[i]
            prev_sum_var = (name, 'sum', i - 1)
            curr_var = variables[i]
            curr_sum_var = get_or_variable(csp, (name, 'sum', i),
                                          list(range(upperBound + 1)))

            # Add ternary constraint: curr_sum_var = prev_sum_var + curr_var
            def make_sum_constraint(prev_val, curr_val, result_val):
                expected_sum = prev_val + curr_val
                return 1.0 if expected_sum == result_val else 0.0

            csp.add_ternary_factor(prev_sum_var, curr_var, curr_sum_var, make_sum_constraint)

    # Link final sum to target variable
    final_sum_var = (name, 'sum', len(variables) - 1)
    csp.add_binary_factor(final_sum_var, name, lambda a, b: 1.0 if a == b else 0.0)

    return name


# Problem 1c: Create Chain CSP
def create_chain_csp(n):
    """
    Create a chain CSP with n variables, each with domain {0, 1}.
    Variables are X_1, X_2, ..., X_n
    Constraints: X_i != X_{i+1} for all i
    
    Args:
        n: Number of variables in the chain
    
    Returns:
        A CSP instance
    """
    csp = CSP()
    
    # Add n variables with domain {0, 1}
    for i in range(n):
        csp.add_variable(i, [0, 1])
    
    # Add binary constraints: adjacent variables must be different
    for i in range(n - 1):
        csp.add_binary_factor(i, i + 1, lambda x, y: 1.0 if x != y else 0.0)
    
    return csp


# Problem 2a: Create N-Queens CSP
def create_nqueens_csp(n):
    """
    Create an N-Queens CSP.
    Variables: Q_0, Q_1, ..., Q_{n-1} (one for each row)
    Domain: {0, 1, ..., n-1} (column positions)
    Constraints: No two queens attack each other
    
    Args:
        n: Size of the board (n x n)
    
    Returns:
        A CSP instance
    """
    csp = CSP()
    
    # Add n variables (one per row), each with domain [0, n-1] (columns)
    for i in range(n):
        csp.add_variable(i, list(range(n)))
    
    # Add constraints between all pairs of queens
    for i in range(n):
        for j in range(i + 1, n):
            # Queens i and j cannot be in the same column
            # Queens i and j cannot be on the same diagonal
            # Diagonal: |row_i - row_j| == |col_i - col_j|
            def make_constraint(row_i, row_j):
                def constraint(col_i, col_j):
                    # Different columns
                    if col_i == col_j:
                        return 0.0
                    # Not on same diagonal
                    if abs(row_i - row_j) == abs(col_i - col_j):
                        return 0.0
                    return 1.0
                return constraint
            
            csp.add_binary_factor(i, j, make_constraint(i, j))
    
    return csp


# COMPLETE FIXED BacktrackingSearch class
class BacktrackingSearch:
    def __init__(self, verbose=0):
        self.numOperations = 0
        self.optimalWeight = 0.0
        self.numOptimalAssignments = 0
        self.optimalAssignment = {}
        self.allAssignments = []
        self.csp = None
        self.mcv = False
        self.use_ac3 = False
        self.domains = None

    def solve(self, csp: CSP, mcv: bool = False, ac3: bool = False) -> None:
        """Solves the CSP by initiating backtracking search."""
        self.csp = csp
        self.mcv = mcv
        self.use_ac3 = ac3

        self.domains = {var: list(csp.values[var]) for var in csp.variables}

        if ac3:
            if not self.ac3(csp):
                return

        self.numOperations = 0
        self.optimalWeight = 0.0
        self.numOptimalAssignments = 0
        self.optimalAssignment = {}
        self.allAssignments = []

        self.backtrack({})

    def ac3(self, csp):
        queue = []
        for var1 in csp.variables:
            for var2 in csp.binaryFactors[var1]:
                queue.append((var1, var2))
        while queue:
            var1, var2 = queue.pop(0)
            if self.revise(csp, var1, var2):
                if not csp.values[var1]:
                    return False
                for var3 in csp.binaryFactors:
                    if var1 in csp.binaryFactors[var3] and var3 != var2:
                        queue.append((var3, var1))
        return True

    def revise(self, csp, var1, var2):
        revised = False
        to_remove = []
        for val1 in csp.values[var1]:
            has_support = False
            for val2 in csp.values[var2]:
                if csp.binaryFactors[var1][var2][val1][val2] > 0:
                    has_support = True
                    break
            if not has_support:
                to_remove.append(val1)
                revised = True
        for val in to_remove:
            csp.values[var1].remove(val)
        return revised

    def backtrack(self, assignment: Dict) -> None:
        self.numOperations += 1
        
        if len(assignment) == len(self.csp.variables):
            weight = self.get_assignment_weight(assignment)
            
            if weight > self.optimalWeight:
                self.optimalWeight = weight
                self.numOptimalAssignments = 1
                self.optimalAssignment = assignment.copy()
                self.allAssignments = [assignment.copy()]
            elif weight == self.optimalWeight:
                self.numOptimalAssignments += 1
                self.allAssignments.append(assignment.copy())
            return
            
        if self.get_assignment_weight(assignment) < self.optimalWeight:
            return

        var = self.get_unassigned_variable(assignment)
        
        for val in self.get_ordered_values(var, assignment):
            if self.satisfies_constraints(assignment, var, val):
                assignment[var] = val
                old_domains = self.set_domains(var, val)
                self.backtrack(assignment)
                del assignment[var]
                self.domains = old_domains

    def get_assignment_weight(self, assignment: Dict) -> float:
        weight = 1.0

        for var in assignment:
            if self.csp.unaryFactors[var] is not None:
                weight *= self.csp.unaryFactors[var][assignment[var]]

        for var1 in assignment:
            for var2 in self.csp.binaryFactors[var1]:
                if var2 in assignment:
                    weight *= self.csp.binaryFactors[var1][var2][assignment[var1]][assignment[var2]]

        for var1 in assignment:
            for var2 in self.csp.ternaryFactors[var1]:
                for var3 in self.csp.ternaryFactors[var1][var2]:
                    if var2 in assignment and var3 in assignment:
                        weight *= self.csp.ternaryFactors[var1][var2][var3][assignment[var1]][assignment[var2]][assignment[var3]]

        return weight

    def satisfies_constraints(self, assignment: Dict, var: str, val) -> bool:
        assignment[var] = val
        weight = self.get_assignment_weight(assignment)
        del assignment[var]
        return weight > 0

    def satisfies_ternary_constraints(self, assignment: Dict, var: str, val) -> bool:
        """Check if assigning val to var satisfies all ternary constraints involving var."""
        assignment[var] = val

        # Check ternary factors involving this variable
        for var1 in assignment:
            if var1 not in self.csp.ternaryFactors:
                continue
            for var2 in self.csp.ternaryFactors[var1]:
                if var2 not in assignment:
                    continue
                for var3 in self.csp.ternaryFactors[var1][var2]:
                    if var3 not in assignment:
                        continue
                    # Check if this ternary factor has zero weight
                    if self.csp.ternaryFactors[var1][var2][var3][assignment[var1]][assignment[var2]][assignment[var3]] == 0.0:
                        del assignment[var]
                        return False

        del assignment[var]
        return True

    def get_ordered_values(self, var: str, assignment: Dict):
        return self.domains[var]

    def set_domains(self, var: str, val):
        old_domains = copy.deepcopy(self.domains)
        self.domains[var] = [val]
        return old_domains

    def get_unassigned_variable(self, assignment: Dict):
        if not self.mcv:
            for var in self.csp.variables:
                if var not in assignment:
                    return var
        else:
            min_count = float('inf')
            mcv_var = None
            
            for var in self.csp.variables:
                if var not in assignment:
                    consistent_count = 0
                    
                    for val in self.domains[var]:
                        if self.satisfies_constraints(assignment, var, val):
                            consistent_count += 1
                    
                    if consistent_count < min_count:
                        min_count = consistent_count
                        mcv_var = var
            
            return mcv_var


# Problem 3: Course Scheduling CSP Constructor
class SchedulingCSPConstructor:
    def __init__(self, bulletin: CourseBulletin, profile: Profile):
        """
        Initialize the CSP constructor.
        
        Args:
            bulletin: Course bulletin with course information
            profile: Student profile with requests and constraints
        """
        self.bulletin = bulletin
        self.profile = profile

    def get_basic_csp(self) -> CSP:
        """
        Create a basic CSP for course scheduling.

        Variables: One per request per quarter (request, quarter)
        Domain: Course IDs that can satisfy the request, plus None
        """
        csp = CSP()

        # For each request, create variables for each quarter
        for request_idx, request in enumerate(self.profile.requests):
            for quarter in self.profile.quarters:
                var = (request_idx, quarter)

                # Domain: courses that can satisfy this request + None (not taking)
                domain = list(request.cids) + [None]
                csp.add_variable(var, domain)

                # Add preference weight as unary factor
                def make_weight_factor(req_weight):
                    def factor(cid):
                        if cid is None:
                            return 0.0
                        return req_weight  # Reward for taking
                    return factor

                csp.add_unary_factor(var, make_weight_factor(request.weight))

        # Constraint: At most one course per request across all quarters
        for request_idx, request in enumerate(self.profile.requests):
            quarters = self.profile.quarters
            for i in range(len(quarters)):
                for j in range(i + 1, len(quarters)):
                    var1 = (request_idx, quarters[i])
                    var2 = (request_idx, quarters[j])

                    # At most one can be non-None
                    def at_most_one(cid1, cid2):
                        if cid1 is not None and cid2 is not None:
                            return 0.0
                        return 1.0

                    csp.add_binary_factor(var1, var2, at_most_one)

        # Note: Removed incorrect constraint that limited to at most one course per quarter
        # Multiple courses can be taken per quarter as long as unit limits are satisfied

        return csp

    def add_quarter_constraints(self, csp: CSP) -> None:
        """
        Add constraints that courses must be taken in requested quarters.
        If a request specifies quarters, only allow those quarters.
        """
        for request_idx, request in enumerate(self.profile.requests):
            if len(request.quarters) > 0:
                # This request has specific quarter requirements
                for quarter in self.profile.quarters:
                    var = (request_idx, quarter)

                    if quarter not in request.quarters:
                        # Not allowed in this quarter - must be None
                        csp.add_unary_factor(var, lambda cid: 1.0 if cid is None else 0.0)

        # Add course offering constraints
        for request_idx, request in enumerate(self.profile.requests):
            for quarter in self.profile.quarters:
                var = (request_idx, quarter)

                def offering_constraint(cid):
                    if cid is None:
                        return 1.0
                    if cid in self.bulletin.courses:
                        course = self.bulletin.courses[cid]
                        if course.is_offered_in(quarter):
                            return 1.0
                    return 0.0

                csp.add_unary_factor(var, offering_constraint)

    def add_unit_constraints(self, csp: CSP) -> None:
        """
        Add constraints for unit loads per quarter.
        Each quarter must have between minUnits and maxUnits.
        """
        for quarter in self.profile.quarters:
            # Collect all variables for this quarter
            quarter_vars = []
            for request_idx, request in enumerate(self.profile.requests):
                quarter_vars.append((request_idx, quarter))
            
            # Create a sum variable for units in this quarter
            sum_var_name = ('units', quarter)
            
            # Create unit variables for each course variable
            unit_vars = []
            for var in quarter_vars:
                unit_var = ('unit', var)
                
                # Get the request to know possible courses
                request_idx, q = var
                request = self.profile.requests[request_idx]
                
                # Domain: unit counts for each possible course + 0 for None
                unit_domain = set([0])  # 0 units if not taking
                for cid in request.cids:
                    if cid in self.bulletin.courses:
                        course = self.bulletin.courses[cid]
                        for units in range(course.minUnits, course.maxUnits + 1):
                            unit_domain.add(units)
                
                unit_domain = sorted(list(unit_domain))
                get_or_variable(csp, unit_var, unit_domain)
                
                # Link unit variable to course variable
                def make_unit_constraint(req_idx):
                    def constraint(cid, units):
                        if cid is None:
                            return 1.0 if units == 0 else 0.0
                        if cid in self.bulletin.courses:
                            course = self.bulletin.courses[cid]
                            # Units must be exactly within the course's unit range
                            if course.minUnits <= units <= course.maxUnits:
                                return 1.0
                        return 0.0
                    return constraint

                csp.add_binary_factor(var, unit_var, make_unit_constraint(request_idx))
                unit_vars.append(unit_var)
            
            # Calculate proper upper bound for sum variable
            upper_bound = sum(max(csp.values[unit_var]) for unit_var in unit_vars)
            create_sum_variable(csp, sum_var_name, unit_vars, upper_bound)
            
            # Constrain sum to be in valid range
            min_units = self.profile.minUnits if self.profile.minUnits else 0
            max_units = self.profile.maxUnits if self.profile.maxUnits else upper_bound
            def valid_unit_range(total):
                if min_units <= total <= max_units:
                    return 1.0
                return 0.0

            csp.add_unary_factor(sum_var_name, valid_unit_range)

    def add_all_additional_constraints(self, csp: CSP) -> None:
        """
        Add all additional constraints including:
        - Quarter constraints
        - Unit constraints
        - Prerequisite constraints
        - Course offering constraints
        """
        self.add_quarter_constraints(csp)
        self.add_unit_constraints(csp)
        
        # Add prerequisite constraints
        for request_idx, request in enumerate(self.profile.requests):
            if len(request.prereqs) > 0:
                for quarter_idx, quarter in enumerate(self.profile.quarters):
                    var = (request_idx, quarter)
                    
                    # For each prerequisite, ensure it's taken in an earlier quarter
                    for prereq in request.prereqs:
                        if prereq not in self.profile.taking:
                            # Find the request that includes this prereq
                            for prereq_req_idx, prereq_req in enumerate(self.profile.requests):
                                if prereq in prereq_req.cids:
                                    # Constrain: if taking this course, prereq must be in earlier quarter
                                    for prereq_quarter_idx in range(quarter_idx):
                                        prereq_var = (prereq_req_idx, self.profile.quarters[prereq_quarter_idx])
                                        
                                        def prereq_constraint(prereq_cid, curr_cid):
                                            if curr_cid == prereq:
                                                # Taking the course that needs prereq
                                                if prereq_cid != prereq:
                                                    return 0.0  # Prereq not satisfied
                                            return 1.0
                                        
                                        csp.add_binary_factor(prereq_var, var, prereq_constraint)
        
        # Add course offering constraints
        for request_idx, request in enumerate(self.profile.requests):
            for quarter in self.profile.quarters:
                var = (request_idx, quarter)
                
                def offering_constraint(cid):
                    if cid is None:
                        return 1.0
                    if cid in self.bulletin.courses:
                        course = self.bulletin.courses[cid]
                        if course.is_offered_in(quarter):
                            return 1.0
                    return 0.0
                
                csp.add_unary_factor(var, offering_constraint)