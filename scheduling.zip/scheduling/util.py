from typing import Any, Callable, Dict, List, Set, Tuple, Optional
import collections
import json

class CSP:
    """
    Constraint Satisfaction Problem class.
    Supports unary, binary, and ternary factors with weighted constraints.
    """
    def __init__(self):
        self.variables: List[Any] = []
        self.values: Dict[Any, List[Any]] = {}  # Variable -> domain
        self.unaryFactors: Dict[Any, Optional[Dict[Any, float]]] = {}
        self.binaryFactors: Dict[Any, Dict[Any, Dict[Any, Dict[Any, float]]]] = {}
        self.ternaryFactors: Dict[Any, Dict[Any, Dict[Any, Dict[Any, Dict[Any, float]]]]] = {}

    def add_variable(self, var: Any, domain: List[Any]) -> None:
        """Add a variable with its domain."""
        if var in self.variables:
            raise ValueError(f"Variable {var} already exists")

        self.variables.append(var)
        self.values[var] = list(domain)
        self.unaryFactors[var] = None
        self.binaryFactors[var] = {}
        self.ternaryFactors[var] = {}

    def add_unary_factor(self, var: Any, factor_func: Callable[[Any], float]) -> None:
        """
        Add a unary factor for a variable.
        factor_func takes a value and returns a weight (0.0 = constraint violated).
        """
        if var not in self.variables:
            raise ValueError(f"Variable {var} not found")
        
        # Create unary factor table
        factor_table = {}
        for value in self.values[var]:
            factor_table[value] = factor_func(value)
        
        # Multiply with existing unary factor if present
        if self.unaryFactors[var] is None:
            self.unaryFactors[var] = factor_table
        else:
            for value in self.values[var]:
                self.unaryFactors[var][value] *= factor_table[value]

    def add_binary_factor(self, var1: Any, var2: Any, 
                         factor_func: Callable[[Any, Any], float]) -> None:
        """
        Add a binary factor between two variables.
        factor_func takes (value1, value2) and returns a weight.
        """
        if var1 not in self.variables or var2 not in self.variables:
            raise ValueError(f"Variables {var1} or {var2} not found")
        
        # Create binary factor table
        factor_table = {}
        for val1 in self.values[var1]:
            factor_table[val1] = {}
            for val2 in self.values[var2]:
                factor_table[val1][val2] = factor_func(val1, val2)
        
        # Store in both directions
        if var2 not in self.binaryFactors[var1]:
            self.binaryFactors[var1][var2] = factor_table
        else:
            # Multiply with existing factor
            for val1 in self.values[var1]:
                for val2 in self.values[var2]:
                    self.binaryFactors[var1][var2][val1][val2] *= factor_table[val1][val2]
        
        # Add reverse direction for consistency
        if var1 not in self.binaryFactors[var2]:
            reverse_table = {}
            for val2 in self.values[var2]:
                reverse_table[val2] = {}
                for val1 in self.values[var1]:
                    reverse_table[val2][val1] = factor_table[val1][val2]
            self.binaryFactors[var2][var1] = reverse_table

    def add_ternary_factor(self, var1: Any, var2: Any, var3: Any,
                          factor_func: Callable[[Any, Any, Any], float]) -> None:
        """
        Add a ternary factor between three variables.
        factor_func takes (value1, value2, value3) and returns a weight.
        """
        if var1 not in self.variables or var2 not in self.variables or var3 not in self.variables:
            raise ValueError(f"Variables {var1}, {var2}, or {var3} not found")

        # Create ternary factor table
        factor_table = {}
        for val1 in self.values[var1]:
            factor_table[val1] = {}
            for val2 in self.values[var2]:
                factor_table[val1][val2] = {}
                for val3 in self.values[var3]:
                    factor_table[val1][val2][val3] = factor_func(val1, val2, val3)

        # Store in all permutations for consistency
        # var1 -> var2 -> var3
        if var2 not in self.ternaryFactors[var1]:
            self.ternaryFactors[var1][var2] = {}
        if var3 not in self.ternaryFactors[var1][var2]:
            self.ternaryFactors[var1][var2][var3] = factor_table
        else:
            # Multiply with existing factor
            for val1 in self.values[var1]:
                for val2 in self.values[var2]:
                    for val3 in self.values[var3]:
                        self.ternaryFactors[var1][var2][var3][val1][val2][val3] *= factor_table[val1][val2][val3]

        # var1 -> var3 -> var2
        if var3 not in self.ternaryFactors[var1]:
            self.ternaryFactors[var1][var3] = {}
        if var2 not in self.ternaryFactors[var1][var3]:
            reverse_table_132 = {}
            for val1 in self.values[var1]:
                reverse_table_132[val1] = {}
                for val3 in self.values[var3]:
                    reverse_table_132[val1][val3] = {}
                    for val2 in self.values[var2]:
                        reverse_table_132[val1][val3][val2] = factor_table[val1][val2][val3]
            self.ternaryFactors[var1][var3][var2] = reverse_table_132

        # var2 -> var1 -> var3
        if var1 not in self.ternaryFactors[var2]:
            self.ternaryFactors[var2][var1] = {}
        if var3 not in self.ternaryFactors[var2][var1]:
            reverse_table_213 = {}
            for val2 in self.values[var2]:
                reverse_table_213[val2] = {}
                for val1 in self.values[var1]:
                    reverse_table_213[val2][val1] = {}
                    for val3 in self.values[var3]:
                        reverse_table_213[val2][val1][val3] = factor_table[val1][val2][val3]
            self.ternaryFactors[var2][var1][var3] = reverse_table_213

        # var2 -> var3 -> var1
        if var3 not in self.ternaryFactors[var2]:
            self.ternaryFactors[var2][var3] = {}
        if var1 not in self.ternaryFactors[var2][var3]:
            reverse_table_231 = {}
            for val2 in self.values[var2]:
                reverse_table_231[val2] = {}
                for val3 in self.values[var3]:
                    reverse_table_231[val2][val3] = {}
                    for val1 in self.values[var1]:
                        reverse_table_231[val2][val3][val1] = factor_table[val1][val2][val3]
            self.ternaryFactors[var2][var3][var1] = reverse_table_231

        # var3 -> var1 -> var2
        if var1 not in self.ternaryFactors[var3]:
            self.ternaryFactors[var3][var1] = {}
        if var2 not in self.ternaryFactors[var3][var1]:
            reverse_table_312 = {}
            for val3 in self.values[var3]:
                reverse_table_312[val3] = {}
                for val1 in self.values[var1]:
                    reverse_table_312[val3][val1] = {}
                    for val2 in self.values[var2]:
                        reverse_table_312[val3][val1][val2] = factor_table[val1][val2][val3]
            self.ternaryFactors[var3][var1][var2] = reverse_table_312

        # var3 -> var2 -> var1
        if var2 not in self.ternaryFactors[var3]:
            self.ternaryFactors[var3][var2] = {}
        if var1 not in self.ternaryFactors[var3][var2]:
            reverse_table_321 = {}
            for val3 in self.values[var3]:
                reverse_table_321[val3] = {}
                for val2 in self.values[var2]:
                    reverse_table_321[val3][val2] = {}
                    for val1 in self.values[var1]:
                        reverse_table_321[val3][val2][val1] = factor_table[val1][val2][val3]
            self.ternaryFactors[var3][var2][var1] = reverse_table_321
        else:
            # Multiply with existing factor
            for val3 in self.values[var3]:
                for val2 in self.values[var2]:
                    for val1 in self.values[var1]:
                        self.ternaryFactors[var3][var2][var1][val3][val2][val1] *= factor_table[val1][val2][val3]


def get_or_variable(csp: CSP, name: Any, domain: List[Any]) -> Any:
    """
    Get an existing variable or create a new one if it doesn't exist.
    
    Args:
        csp: The CSP instance
        name: Variable name/identifier
        domain: Domain for the variable
        
    Returns:
        The variable name
    """
    if name not in csp.variables:
        csp.add_variable(name, domain)
    return name


# ============================================================================
# Course Scheduling Classes
# ============================================================================

class Course:
    """Represents a course with its properties."""
    def __init__(self, cid: str, minUnits: int, maxUnits: int, 
                 prereqs: List[str] = None, quarters: List[str] = None):
        self.cid = cid
        self.minUnits = minUnits
        self.maxUnits = maxUnits
        self.prereqs = prereqs if prereqs else []
        self.quarters = quarters if quarters else []  # Quarters when offered
    
    def is_offered_in(self, quarter: str) -> bool:
        """Check if course is offered in a given quarter."""
        if not self.quarters:  # If empty, offered in all quarters
            return True
        return quarter in self.quarters


class CourseBulletin:
    """Contains information about all available courses."""
    def __init__(self, filename: Optional[str] = None):
        self.courses: Dict[str, Course] = {}
        if filename:
            self.load_from_json(filename)
    
    def add_course(self, course: Course) -> None:
        """Add a course to the bulletin."""
        self.courses[course.cid] = course
    
    def load_from_json(self, filename: str) -> None:
        """Load courses from a JSON file."""
        with open(filename, 'r') as f:
            data = json.load(f)
        
        for cid, course_data in data.items():
            course = Course(
                cid=cid,
                minUnits=course_data.get('minUnits', 3),
                maxUnits=course_data.get('maxUnits', 5),
                prereqs=course_data.get('prereqs', []),
                quarters=course_data.get('quarters', [])
            )
            self.add_course(course)


class Request:
    """Represents a course request from a student."""
    def __init__(self, cids: List[str], weight: float = 1.0, 
                 quarters: List[str] = None, prereqs: List[str] = None):
        self.cids = cids  # List of acceptable course IDs
        self.weight = weight  # Preference weight
        self.quarters = quarters if quarters else []  # Preferred quarters
        self.prereqs = prereqs if prereqs else []  # Prerequisites


class Profile:
    """Student profile with scheduling preferences."""
    def __init__(self, bulletin: CourseBulletin, filename: str):
        """
        Initialize profile from a file.
        
        Args:
            bulletin: Course bulletin
            filename: Path to profile text file
        """
        self.bulletin = bulletin
        self.quarters = []
        self.minUnits = None
        self.maxUnits = None
        self.requests: List[Request] = []
        self.taking: Set[str] = set()
        
        # Parse the profile file
        self.load_from_file(filename)
    
    def load_from_file(self, filename: str) -> None:
        """Load profile from text file."""
        with open(filename, 'r') as f:
            lines = [line.strip() for line in f if line.strip() and not line.startswith('#')]

        for line in lines:
            parts = line.split()
            if not parts:
                continue

            keyword = parts[0]

            if keyword == 'minUnits':
                self.minUnits = int(parts[1])
            elif keyword == 'maxUnits':
                self.maxUnits = int(parts[1])
            elif keyword == 'register':
                self.quarters.append(parts[1])
            elif keyword == 'taken':
                self.taking.add(parts[1])
            elif keyword == 'request':
                # Parse request line: request CID [or CID]* [in quarters]* [weight W] [after prereqs]
                # Find positions
                in_index = -1
                weight_index = -1
                after_index = -1
                for idx, part in enumerate(parts):
                    if part == 'in':
                        in_index = idx
                    elif part == 'weight':
                        weight_index = idx
                    elif part == 'after':
                        after_index = idx

                # Determine cid_str end
                end_cid = len(parts)
                if in_index != -1:
                    end_cid = min(end_cid, in_index)
                if weight_index != -1:
                    end_cid = min(end_cid, weight_index)
                if after_index != -1:
                    end_cid = min(end_cid, after_index)

                cid_str = ' '.join(parts[1:end_cid])
                cids = [cid.strip() for cid in cid_str.split('or')]

                # Quarters
                quarters = []
                if in_index != -1:
                    start_q = in_index + 1
                    end_q = len(parts)
                    if weight_index != -1:
                        end_q = min(end_q, weight_index)
                    if after_index != -1:
                        end_q = min(end_q, after_index)
                    quarters_str = ' '.join(parts[start_q:end_q])
                    quarters = [q.strip() for q in quarters_str.split(',') if q.strip()]

                # Weight
                weight = 1.0
                if weight_index != -1:
                    weight = float(parts[weight_index + 1])

                # Prereqs
                prereqs = []
                if after_index != -1:
                    prereqs_str = ' '.join(parts[after_index + 1:])
                    prereqs = [p.strip() for p in prereqs_str.split(',') if p.strip()]

                request = Request(cids, weight=weight, quarters=quarters, prereqs=prereqs)
                self.requests.append(request)
    
    def add_request(self, request: Request) -> None:
        """Add a course request."""
        self.requests.append(request)
    
    def add_taking(self, cid: str) -> None:
        """Mark a course as already taken/taking."""
        self.taking.add(cid)


# ============================================================================
# Utility Functions
# ============================================================================

def extract_course_scheduling_solution(profile: Profile, assignment: Dict) -> List[Tuple[str, str, int]]:
    """
    Extract a readable course schedule from a CSP assignment.
    
    Args:
        profile: Student profile
        assignment: CSP assignment dictionary
        
    Returns:
        List of tuples (quarter, cid, units) for each scheduled course
    """
    schedule = []
    
    for var, val in assignment.items():
        # Check if this is a request variable (just an integer index)
        if isinstance(var, int) and var < len(profile.requests):
            # Skip if no course assigned (None)
            if val is None:
                continue
            
            # val is (quarter, cid)
            quarter, cid = val
            
            # Get the units - try to find from assignment
            unit_var = ('unit', var, quarter)
            if unit_var in assignment:
                units = assignment[unit_var]
            elif cid in profile.bulletin.courses:
                # Default to minimum units if not found
                course = profile.bulletin.courses[cid]
                units = course.minUnits
            else:
                units = 3  # Default fallback
            
            schedule.append((quarter, cid, units))
    
    return schedule


def create_map_coloring_csp() -> CSP:
    """
    Create a map coloring CSP for testing.
    Classic graph coloring problem.
    """
    csp = CSP()
    
    # Variables are regions, values are colors
    regions = ['A', 'B', 'C', 'D']
    colors = ['Red', 'Green', 'Blue']
    
    # Add variables
    for region in regions:
        csp.add_variable(region, colors)
    
    # Add constraints: adjacent regions must have different colors
    adjacencies = [('A', 'B'), ('A', 'C'), ('B', 'C'), ('B', 'D'), ('C', 'D')]
    
    for region1, region2 in adjacencies:
        csp.add_binary_factor(region1, region2, lambda x, y: 1.0 if x != y else 0.0)
    
    return csp


# ============================================================================
# Helper Functions for Testing
# ============================================================================

def print_solution(assignment: Dict, bulletin: CourseBulletin = None) -> None:
    """Pretty print a CSP solution."""
    if not assignment:
        print("No solution found")
        return
    
    # Group by quarters if applicable
    by_quarter = collections.defaultdict(list)
    other = []
    
    for var, val in sorted(assignment.items(), key=str):
        if isinstance(var, tuple) and len(var) == 2:
            request, quarter = var
            if val is not None:
                by_quarter[quarter].append((request, val))
        else:
            other.append((var, val))
    
    # Print by quarter
    for quarter in sorted(by_quarter.keys()):
        print(f"\n{quarter}:")
        for request, cid in by_quarter[quarter]:
            if bulletin and cid in bulletin.courses:
                course = bulletin.courses[cid]
                print(f"  {cid} ({course.minUnits}-{course.maxUnits} units)")
            else:
                print(f"  {cid}")
    
    # Print other variables
    if other:
        print("\nOther variables:")
        for var, val in other:
            print(f"  {var}: {val}")


def create_test_bulletin() -> CourseBulletin:
    """Create a sample course bulletin for testing."""
    bulletin = CourseBulletin()
    
    # Add some sample courses
    bulletin.add_course(Course("CS101", 3, 5, [], ["Fall", "Winter", "Spring"]))
    bulletin.add_course(Course("CS102", 3, 5, ["CS101"], ["Winter", "Spring"]))
    bulletin.add_course(Course("CS103", 3, 4, [], ["Fall", "Spring"]))
    bulletin.add_course(Course("MATH101", 4, 5, [], ["Fall", "Winter", "Spring"]))
    bulletin.add_course(Course("MATH102", 3, 5, ["MATH101"], ["Winter", "Spring"]))
    
    return bulletin


def create_test_profile(bulletin: CourseBulletin) -> Profile:
    """Create a sample student profile for testing."""
    # Note: This would normally load from a file
    # This is just for testing without a file
    profile = Profile.__new__(Profile)
    profile.bulletin = bulletin
    profile.quarters = ["Fall", "Winter", "Spring"]
    profile.minUnits = 12
    profile.maxUnits = 15
    profile.requests = []
    profile.taking = set()

    # Add some course requests
    profile.add_request(Request(["CS101", "CS103"], weight=2.0))
    profile.add_request(Request(["MATH101"], weight=1.5))
    profile.add_request(Request(["CS102"], weight=1.0, quarters=["Spring"]))

    return profile


def create_nqueens_csp(n):
    """
    Create an N-Queens CSP.
    Variables: Q_0, Q_1, ..., Q_{n-1} (one for each row)
    Domain: {0, 1, ..., n-1} (column positions)
    Constraints: No two queens attack each other

    Args:
        n: Size of the board (n x n)

    Returns:
        A CSP instance
    """
    csp = CSP()

    # Add n variables (one per row), each with domain [0, n-1] (columns)
    for i in range(n):
        csp.add_variable(i, list(range(n)))

    # Add constraints between all pairs of queens
    for i in range(n):
        for j in range(i + 1, n):
            # Queens i and j cannot be in the same column
            # Queens i and j cannot be on the same diagonal
            # Diagonal: |row_i - row_j| == |col_i - col_j|
            def make_constraint(row_i, row_j):
                def constraint(col_i, col_j):
                    # Different columns
                    if col_i == col_j:
                        return 0.0
                    # Not on same diagonal
                    if abs(row_i - row_j) == abs(col_i - col_j):
                        return 0.0
                    return 1.0
                return constraint

            csp.add_binary_factor(i, j, make_constraint(i, j))

    return csp


def create_weighted_csp() -> CSP:
    """
    Create a weighted CSP for testing.
    Simple example with preferences.
    """
    csp = CSP()

    # Variables: A, B, C
    # Domains: [0, 1, 2]
    for var in ['A', 'B', 'C']:
        csp.add_variable(var, [0, 1, 2])

    # Unary factors: prefer higher values
    for var in ['A', 'B', 'C']:
        csp.add_unary_factor(var, lambda x: x + 1.0)  # 1.0 for 0, 2.0 for 1, 3.0 for 2

    # Binary constraint: A + B <= 3
    csp.add_binary_factor('A', 'B', lambda a, b: 1.0 if a + b <= 3 else 0.0)

    # Binary constraint: B + C <= 3
    csp.add_binary_factor('B', 'C', lambda b, c: 1.0 if b + c <= 3 else 0.0)

    return csp
    return profile