import collections
import math
from typing import Any, DefaultDict, List, Set, Tuple

############################################################
# Custom Types
# NOTE: You do not need to modify these.

"""
You can think of the keys of the defaultdict as representing the positions in
the sparse vector, while the values represent the elements at those positions.
Any key which is absent from the dict means that that element in the sparse
vector is absent (is zero).
Note that the type of the key used should not affect the algorithm. You can
imagine the keys to be integer indices (e.g., 0, 1, 2) in the sparse vectors,
but it should work the same way with arbitrary keys (e.g., "red", "blue",
"green").

"""
from collections import defaultdict

SparseVector = DefaultDict[Any, float]
Position = Tuple[int, int]



############################################################
# Problem 4a

def find_alphabetically_first_word(text: str) -> str:
    """
    Given a string |text|, return the word in |text| that comes first lexicographically (i.e., the word that would come first after sorting).
    A word is defined by a maximal sequence of characters without whitespaces.
    If |text| is an empty string, this function returns an empty string.
    """
    words = text.split()
    if not words:
        return ""
    return min(words)   # return the smallest word



"""
    Given a string |text|, return the word in |text| that comes first
    lexicographically (i.e., the word that would come first after sorting).
    A word is defined by a maximal sequence of characters without whitespaces.
    Words are case sensitive -- i.e. we may not assume that letters are all in lowercase.
    You might find min() handy here. If the input text is an empty string,
    it is acceptable to either return an empty string or throw an error.
    """
    
    # BEGIN_YOUR_CODE (our solution is 1 line of code, but don't worry if you deviate from this)
#raise Exception("Not implemented yet")
    # END_YOUR_CODE


############################################################
# Problem 4b
import math
from typing import Tuple

def euclidean_distance(loc1: Tuple[float, float], loc2: Tuple[float, float]) -> float:
    """
    Return the Euclidean distance between two locations (x1, y1) and (x2, y2).
    """
    return math.sqrt((loc2[0] - loc1[0])**2 + (loc2[1] - loc1[1])**2)






    # BEGIN_YOUR_CODE (our solution is 1 line of code, but don't worry if you deviate from this)
#raise Exception("Not implemented yet")
    # END_YOUR_CODE


############################################################
# Problem 4c


from typing import List

def mutate_sentences(sentence: str) -> List[str]:
    """
    Given a sentence (sequence of words), return a list of all "similar"
    sentences.
    We define a sentence to be "similar" to the original sentence if
      - it has the same number of words, and
      - each pair of adjacent words in the new sentence also occurs in the
        original sentence (the words within each pair should appear in the same
        order in the output sentence as they did in the original sentence).
    Notes:
      - The order of the sentences you output doesn't matter.
      - You must not output duplicates.
      - Your generated sentence can use a word in the original sentence more
        than once.
    Example:
      - Input: 'the cat and the mouse'
      - Output: ['and the cat and the', 'the cat and the mouse',
                 'the cat and the cat', 'cat and the cat and']
                 (Reordered versions of this list are allowed.)
    """
    # Step 1: Break the sentence into words
    words = sentence.split()
    n = len(words)  # total number of words

    # Step 2: Build adjacency list of valid "next words"
    adj = {}
    for i in range(len(words) - 1):
        adj.setdefault(words[i], set()).add(words[i + 1])

    # Step 3: Store results in a set (to avoid duplicates)
    results = set()

    # Step 4: DFS (Depth-First Search) to build sentences
    def dfs(path):
        if len(path) == n:  # base case
            results.add(" ".join(path))
            return
        last_word = path[-1]
        if last_word in adj:
            for nxt in adj[last_word]:
                dfs(path + [nxt])

    # Step 5: Try starting from every unique word
    for w in set(words):
        dfs([w])

    return list(results)




"""
Given a sentence (sequence of words), return a list of all "similar"
    sentences.
    We define a sentence to be "similar" to the original sentence if
      - it has the same number of words, and
      - each pair of adjacent words in the new sentence also occurs in the
        original sentence (the words within each pair should appear in the same
        order in the output sentence as they did in the original sentence).
    Notes:
      - The order of the sentences you output doesn't matter.
      - You must not output duplicates.
      - Your generated sentence can use a word in the original sentence more
        than once.
    Example:
      - Input: 'the cat and the mouse'
      - Output: ['and the cat and the', 'the cat and the mouse',
                 'the cat and the cat', 'cat and the cat and']
                (Reordered versions of this list are allowed.)
    """
    # BEGIN_YOUR_CODE (our solution is 20 lines of code, but don't worry if you deviate from this)
#raise Exception("Not implemented yet")
    # END_YOUR_CODE


############################################################
# Problem 4d


from collections import defaultdict

def sparse_vector_dot_product(v1: defaultdict, v2: defaultdict) -> float:
    """
    Given two sparse vectors (vectors where most of the elements are zeros)
    |v1| and |v2|, each represented as collections.defaultdict(float), return
    their dot product.

    You might find it useful to use sum() and a list comprehension.
    This function will be useful later for linear classifiers.
    Note: A sparse vector has most of its entries as 0.
    """
    # Only iterate over keys in v1 (or v2), multiply if key exists in both
    return sum(v1[i] * v2[i] for i in v1 if i in v2)


"""
    Given two sparse vectors (vectors where most of the elements are zeros)
    |v1| and |v2|, each represented as collections.defaultdict(float), return
    their dot product.

    You might find it useful to use sum() and a list comprehension.
    This function will be useful later for linear classifiers.
    Note: A sparse vector has most of its entries as 0.
    """
    # BEGIN_YOUR_CODE (our solution is 1 line of code, but don't worry if you deviate from this)
#raise Exception("Not implemented yet")
    # END_YOUR_CODE


############################################################
# Problem 4e

def increment_sparse_vector(v1: SparseVector, scale: float, v2: SparseVector,
) -> None:
    """
    Given two sparse vectors |v1| and |v2|, perform v1 += scale * v2.
    If the scale is zero, you are allowed to modify v1 to include any
    additional keys in v2, or just not add the new keys at all.

    NOTE: This function should MODIFY v1 in-place, but not return it.
    Do not modify v2 in your implementation.
    This function will be useful later for linear classifiers.
    """
    for key, value in v2.items():
        v1[key] += scale * value



    """
    Given two sparse vectors |v1| and |v2|, perform v1 += scale * v2.
    If the scale is zero, you are allowed to modify v1 to include any
    additional keys in v2, or just not add the new keys at all.

    NOTE: This function should MODIFY v1 in-place, but not return it.
    Do not modify v2 in your implementation.
    This function will be useful later for linear classifiers.
    """
    # BEGIN_YOUR_CODE (our solution is 2 lines of code, but don't worry if you deviate from this)
    #raise Exception("Not implemented yet")
    # END_YOUR_CODE


############################################################
# Problem 4f


from collections import defaultdict

def find_nonsingleton_words(text: str) -> set:
    """
    Split the string |text| by whitespace and return the set of words that
    occur more than once.
    You might find it useful to use collections.defaultdict(int).
    """
    word_count = defaultdict(int)

    # Count occurrences of each word
    for word in text.split():
        word_count[word] += 1

    # Return words that appear more than once
    return {word for word, count in word_count.items() if count > 1}



    """
    Split the string |text| by whitespace and return the set of words that
    occur more than once.
    You might find it useful to use collections.defaultdict(int).
    """
    # BEGIN_YOUR_CODE (our solution is 4 lines of code, but don't worry if you deviate from this)
    #raise Exception("Not implemented yet")
    # END_YOUR_CODE
