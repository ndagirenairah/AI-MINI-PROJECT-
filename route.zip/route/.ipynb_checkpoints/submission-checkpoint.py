from typing import List, Tuple 

from mapUtil import (
    CityMap,
    computeDistance,
    createStanfordMap,
    locationFromTag,
    makeTag,
)
from util import Heuristic, SearchProblem, State, UniformCostSearch

########################################################################################
# Problem 2a: Modeling the Shortest Path Problem.

class ShortestPathProblem(SearchProblem):
    """
    Defines a search problem that corresponds to finding the shortest path
    from `startLocation` to any location with the specified `endTag`.
    """

    def __init__(self, startLocation: str, endTag: str, cityMap: CityMap):
        self.startLocation = startLocation
        self.endTag = endTag
        self.cityMap = cityMap

    def startState(self) -> State:
        return State(memory=self.startLocation)

    def isEnd(self, state: State) -> bool:
        locTags = self.cityMap.getLocationTags(state.memory)
        return self.endTag in locTags

    def actionSuccessorsAndCosts(self, state: State) -> List[Tuple[str, State, float]]:
        successors = []
        currentLoc = state.memory
        for neighbor, dist in self.cityMap.getNeighbors(currentLoc).items():
            successors.append((neighbor, State(memory=neighbor), dist))
        return successors

########################################################################################
# Problem 2b: Custom -- Plan a Route through Stanford

def getStanfordShortestPathProblem() -> ShortestPathProblem:
    cityMap = createStanfordMap()
    startLocation = "6608739360"  # Example Gates Building node ID
    endTag = "amenity=food"       # Example tag
    return ShortestPathProblem(startLocation, endTag, cityMap)

########################################################################################
# Problem 3a: Modeling the Waypoints Shortest Path Problem.

class WaypointsShortestPathProblem(SearchProblem):
    def __init__(
        self, startLocation: str, waypointTags: List[str], endTag: str, cityMap: CityMap
    ):
        self.startLocation = startLocation
        self.endTag = endTag
        self.cityMap = cityMap
        self.waypointTags = tuple(sorted(waypointTags))

    def startState(self) -> State:
        covered = set(self.cityMap.getLocationTags(self.startLocation)) & set(self.waypointTags)
        return State(memory=(self.startLocation, frozenset(covered)))

    def isEnd(self, state: State) -> bool:
        loc, covered = state.memory
        return self.endTag in self.cityMap.getLocationTags(loc) and covered == set(self.waypointTags)

    def actionSuccessorsAndCosts(self, state: State) -> List[Tuple[str, State, float]]:
        successors = []
        loc, covered = state.memory
        for neighbor, dist in self.cityMap.getNeighbors(loc).items():
            neighborTags = self.cityMap.getLocationTags(neighbor)
            newCovered = set(covered) | (set(neighborTags) & set(self.waypointTags))
            successors.append((neighbor, State(memory=(neighbor, frozenset(newCovered))), dist))
        return successors

########################################################################################
# Problem 3c: Custom -- Plan a Route with Unordered Waypoints through Stanford

def getStanfordWaypointsShortestPathProblem() -> WaypointsShortestPathProblem:
    cityMap = createStanfordMap()
    startLocation = "6608739360"                  # Example Gates Building
    waypointTags = ["amenity=food", "amenity=parking_entrance"]
    endTag = "landmark=Tresidder"                # Example end landmark
    return WaypointsShortestPathProblem(startLocation, waypointTags, endTag, cityMap)

########################################################################################
# Problem 4a: A* to UCS reduction

def aStarReduction(problem: SearchProblem, heuristic: Heuristic) -> SearchProblem:
    class NewSearchProblem(SearchProblem):
        def startState(self) -> State:
            return State(memory=(problem.startState(), 0.0))

        def isEnd(self, state: State) -> bool:
            return problem.isEnd(state.memory[0])

        def actionSuccessorsAndCosts(self, state: State) -> List[Tuple[str, State, float]]:
            successors = []
            currState, g = state.memory
            for action, nextState, cost in problem.actionSuccessorsAndCosts(currState):
                h = heuristic.evaluate(nextState)
                successors.append((action, State(memory=(nextState, g + cost)), cost + h - heuristic.evaluate(currState)))
            return successors

    return NewSearchProblem()

########################################################################################
# Problem 4b: "straight-line" heuristic for A*

class StraightLineHeuristic(Heuristic):
    def __init__(self, endTag: str, cityMap: CityMap):
        self.endTag = endTag
        self.cityMap = cityMap
        self.endLocations = [loc for loc in cityMap.getLocations() if endTag in cityMap.getLocationTags(loc)]

    def evaluate(self, state: State) -> float:
        loc = state.memory
        return min(computeDistance(self.cityMap.getLatLon(loc), self.cityMap.getLatLon(endLoc)) for endLoc in self.endLocations)

########################################################################################
# Problem 4c: "no waypoints" heuristic for A*

class NoWaypointsHeuristic(Heuristic):
    def __init__(self, endTag: str, cityMap: CityMap):
        self.cityMap = cityMap
        self.endTag = endTag

        class ReverseShortestPathProblem(SearchProblem):
            def startState(self) -> State:
                return State(memory="END")

            def isEnd(self, state: State) -> bool:
                return False

            def actionSuccessorsAndCosts(self, state: State) -> List[Tuple[str, State, float]]:
                successors = []
                if state.memory == "END":
                    for loc in cityMap.getLocations():
                        if endTag in cityMap.getLocationTags(loc):
                            successors.append((loc, State(memory=loc), 0.0))
                else:
                    for neighbor, cost in cityMap.getNeighbors(state.memory).items():
                        successors.append((neighbor, State(memory=neighbor), cost))
                return successors

        ucs = UniformCostSearch()
        ucs.solve(ReverseShortestPathProblem())
        self.costs = ucs.pastCosts

    def evaluate(self, state: State) -> float:
        return self.costs.get(state.memory, float('inf'))
