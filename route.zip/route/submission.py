from typing import List, Tuple, Iterable, Optional
from mapUtil import (
    CityMap,
    computeDistance,
    createStanfordMap,
    locationFromTag,
    makeTag,
)
from util import Heuristic, SearchProblem, State, UniformCostSearch, State

########################################################################################
# Problem 2a: Modeling the Shortest Path Problem.

class ShortestPathProblem(SearchProblem):
    """
    Defines a search problem that corresponds to finding the shortest path
    from `startLocation` to any location with the specified `endTag`.
    """

    def __init__(self, startLocation: str, endTag: str, cityMap: CityMap):
        self.startLocation = startLocation
        self.endTag = endTag
        self.cityMap = cityMap

    def startState(self) -> State:
        return State(location=self.startLocation, memory=self.startLocation)

    def isEnd(self, state: State) -> bool:
        loc = state.location
        tags = self.cityMap.tags[loc]
        return self.endTag in tags

    def actionSuccessorsAndCosts(self, state: State) -> List[Tuple[str, State, float]]:
        successors: List[Tuple[str, State, float]] = []
        currentLoc: str = state.location
        # Use cityMap.distances to get neighbors
        for neighbor, dist in self.cityMap.distances[currentLoc].items():
            successors.append((neighbor, State(location=neighbor, memory=neighbor), float(dist)))
        return successors

########################################################################################
# Problem 2b: Custom -- Plan a Route through Stanford

def getStanfordShortestPathProblem() -> ShortestPathProblem:
    cityMap = createStanfordMap()
    startLocation = locationFromTag(makeTag("landmark", "gates"), cityMap)
    endTag = "amenity=food"
    return ShortestPathProblem(startLocation, endTag, cityMap)

########################################################################################
# Problem 3a: Modeling the Waypoints Shortest Path Problem.

class WaypointsShortestPathProblem(SearchProblem):
    """
    State.memory = (current_location: str, covered_waypoint_tags: frozenset)
    waypointTags are canonicalized (sorted tuple) and stored in self.waypointTags.
    """

    def __init__(
        self, startLocation: str, waypointTags: List[str], endTag: str, cityMap: CityMap
    ):
        self.startLocation = startLocation
        self.endTag = endTag
        self.cityMap = cityMap
        self.waypointTags = tuple(sorted(waypointTags))

    def startState(self) -> State:
        start_tags = set(self.cityMap.tags[self.startLocation])
        covered = set(self.waypointTags) & start_tags
        return State(
            location=self.startLocation, 
            memory=(self.startLocation, frozenset(covered))
        )

    def isEnd(self, state: State) -> bool:
        loc, covered = state.memory
        tags_here = set(self.cityMap.tags[loc])
        return (set(self.waypointTags) <= set(covered)) and (self.endTag in tags_here)

    def actionSuccessorsAndCosts(self, state: State) -> List[Tuple[str, State, float]]:
        successors: List[Tuple[str, State, float]] = []
        loc, covered = state.memory
        # Use cityMap.distances to get neighbors
        for neighbor, dist in self.cityMap.distances[loc].items():
            neighbor_tags = set(self.cityMap.tags[neighbor])
            newly_covered = set(covered) | (neighbor_tags & set(self.waypointTags))
            successors.append(
                (neighbor, State(location=neighbor, memory=(neighbor, frozenset(newly_covered))), float(dist))
            )
        return successors

########################################################################################
# Problem 3c: Custom -- Plan a Route with Unordered Waypoints through Stanford

def getStanfordWaypointsShortestPathProblem() -> WaypointsShortestPathProblem:
    cityMap = createStanfordMap()
    startLocation = locationFromTag(makeTag("landmark", "gates"), cityMap)
    waypointTags = ["amenity=food", "amenity=parking_entrance"]
    endTag = "landmark=Tresidder"
    return WaypointsShortestPathProblem(startLocation, waypointTags, endTag, cityMap)

########################################################################################
# Problem 4a: A* to UCS reduction

def aStarReduction(problem: SearchProblem, heuristic: Heuristic) -> SearchProblem:
    """
    Return a SearchProblem such that running UCS on it is equivalent to running A*
    on the original 'problem' with 'heuristic'. We do the standard reduction:
    For each transition s -> s' with cost c, the new cost is c + h(s') - h(s).
    """

    class NewSearchProblem(SearchProblem):
        def startState(self) -> State:
            original_state = problem.startState()
            loc = original_state.location
            return State(location=loc, memory=original_state)

        def isEnd(self, state: State) -> bool:
            original_state: State = state.memory
            return problem.isEnd(original_state)

        def actionSuccessorsAndCosts(self, state: State) -> List[Tuple[str, State, float]]:
            original_state: State = state.memory
            successors: List[Tuple[str, State, float]] = []
            for action, nextState, cost in problem.actionSuccessorsAndCosts(original_state):
                h_curr = heuristic.evaluate(original_state)
                h_next = heuristic.evaluate(nextState)
                adjusted_cost = float(cost) + float(h_next) - float(h_curr)
                loc = nextState.location
                successors.append((action, State(location=loc, memory=nextState), adjusted_cost))
            return successors

    return NewSearchProblem()

########################################################################################
# Problem 4b: "straight-line" heuristic for A*

class StraightLineHeuristic(Heuristic):
    def __init__(self, endTag: str, cityMap: CityMap):
        self.endTag = endTag
        self.cityMap = cityMap

        # Precompute list of end-locations and their geolocations
        self.endLocations = [loc for loc, tags in cityMap.tags.items() if endTag in tags]
        self.endGeoLocations = [cityMap.geoLocations[loc] for loc in self.endLocations] if self.endLocations else []

    def evaluate(self, state: State) -> float:
        loc = state.location
        if loc is None or not self.endLocations:
            return 0.0
        # Get geolocation of current location
        currentGeoLocation = self.cityMap.geoLocations[loc]
        # Return minimum straight-line distance to any end location
        min_dist = min(computeDistance(currentGeoLocation, endGeoLoc) for endGeoLoc in self.endGeoLocations)
        return float(min_dist)

########################################################################################
# Problem 4c: "no waypoints" heuristic for A*

class NoWaypointsHeuristic(Heuristic):
    """
    Precompute the minimum cost from every location to any location with endTag,
    ignoring waypoints. We'll do this by creating a reverse search problem whose
    special start connects to all end locations with cost 0, then run UCS once.
    """

    def __init__(self, endTag: str, cityMap: CityMap):
        self.cityMap = cityMap
        self.endTag = endTag

        class ReverseShortestPathProblem(SearchProblem):
            def startState(self) -> State:
                return State(location=None, memory="__END__")

            def isEnd(self, state: State) -> bool:
                return False

            def actionSuccessorsAndCosts(self, state: State) -> List[Tuple[str, State, float]]:
                successors: List[Tuple[str, State, float]] = []
                mem = state.memory
                if mem == "__END__":
                    # Connect to all locations that have endTag with cost 0
                    for loc, tags in cityMap.tags.items():
                        if endTag in tags:
                            successors.append((loc, State(location=loc, memory=loc), 0.0))
                else:
                    # Normal neighbors - use cityMap.distances
                    for neighbor, cost in cityMap.distances[mem].items():
                        successors.append((neighbor, State(location=neighbor, memory=neighbor), float(cost)))
                return successors

        # Run UCS once on the reverse problem
        ucs = UniformCostSearch()
        ucs.solve(ReverseShortestPathProblem())
        self.costs = dict(ucs.pastCosts)

    def evaluate(self, state: State) -> float:
        loc = state.location
        if loc is None:
            return float("inf")
        return float(self.costs.get(loc, float("inf")))
