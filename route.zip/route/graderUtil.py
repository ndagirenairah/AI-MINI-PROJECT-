"""
Library to do grading of Python programs.
Usage (see grader.py):

    # create a grader
    grader = Grader("Name of assignment")

    # add a basic test
    grader.addBasicPart(number, grade_func, max_points, max_seconds, description="a basic test")

    # add a hidden test
    grader.addHiddenPart(number, grade_func, max_points, max_seconds, description="a hidden test")

    # add a manual grading part
    grader.addManualPart(number, grade_func, max_points, description="written problem")

    # run grading
    grader.grade()
"""

import argparse
import datetime
import gc
import json
import os
import signal
import sys
import traceback

default_max_seconds = 5  # 5 second
TOLERANCE = 1e-4  # For measuring whether two floats are equal

BASIC_MODE = 'basic'  # basic
AUTO_MODE = 'auto'  # basic + hidden
ALL_MODE = 'all'  # basic + hidden + manual


# When reporting stack traces as feedback, ignore parts specific to the grading
# system.
def is_traceback_item_grader(item):
    return item[0].endswith('graderUtil.py')


def is_collection(x):
    return isinstance(x, list) or isinstance(x, tuple)


# Return whether two answers are equal.
def is_equal(true_answer, pred_answer, tolerance=TOLERANCE):
    # Handle floats specially
    if isinstance(true_answer, float) or isinstance(pred_answer, float):
        return abs(true_answer - pred_answer) < tolerance
    # Recurse on collections to deal with floats inside them
    if is_collection(true_answer) and is_collection(pred_answer) and len(true_answer) == len(pred_answer):
        for a, b in zip(true_answer, pred_answer):
            if not is_equal(a, b):
                return False
        return True
    if isinstance(true_answer, dict) and isinstance(pred_answer, dict):
        if len(true_answer) != len(pred_answer):
            return False
        for k, v in list(true_answer.items()):
            if not is_equal(pred_answer.get(k), v):
                return False
        return True

    # Numpy array comparison
    if type(true_answer).__name__ == 'ndarray':
        import numpy as np
        if isinstance(true_answer, np.ndarray) and isinstance(pred_answer, np.ndarray):
            if true_answer.shape != pred_answer.shape:
                return False
            for a, b in zip(true_answer, pred_answer):
                if not is_equal(a, b):
                    return False
            return True

    # Do normal comparison
    return true_answer == pred_answer


# Run a function, timing out after max_seconds.
class TimeoutFunctionException(Exception):
    pass


class TimeoutFunction:
    def __init__(self, function, max_seconds):
        self.max_seconds = max_seconds
        self.function = function

    @staticmethod
    def handle_max_seconds(signum, frame):
        print('TIMEOUT!')
        raise TimeoutFunctionException()

    def __call__(self, *args):
        # The os.name check is already a good fallback for Windows lack of SIGALRM
        if os.name == 'nt':
            # Windows does not have signal.SIGALRM
            # Will not stop after max_seconds second but can still throw an exception
            time_start = datetime.datetime.now()
            result = self.function(*args)
            time_end = datetime.datetime.now()
            if time_end - time_start > datetime.timedelta(seconds=self.max_seconds + 1):
                raise TimeoutFunctionException()
            return result
            # End modification for Windows here
        
        signal.signal(signal.SIGALRM, self.handle_max_seconds)
        signal.alarm(self.max_seconds + 1)
        result = self.function(*args)
        signal.alarm(0)
        return result


class Part:
    def __init__(self, number, grade_func, max_points, max_seconds, extra_credit, description, basic):
        if not isinstance(number, str):
            raise Exception("Invalid number: %s" % number)
        if grade_func is not None and not callable(grade_func):
            raise Exception("Invalid grade_func: %s" % grade_func)
        if not isinstance(max_points, int) and not isinstance(max_points, float):
            raise Exception("Invalid max_points: %s" % max_points)
        if max_seconds is not None and not isinstance(max_seconds, int):
            raise Exception("Invalid max_seconds: %s" % max_seconds)
        if not description:
            print('ERROR: description required for part {}'.format(number))
        # Specification of part
        self.number = number  # Unique identifier for this part.
        self.description = description  # Description of this part
        self.grade_func = grade_func  # Function to call to do grading
        self.max_points = max_points  # Maximum number of points attainable on this part
        self.max_seconds = max_seconds  # Maximum allowed time that the student's code can take (in seconds)
        self.extra_credit = extra_credit  # Whether this is an extra credit problem
        self.basic = basic
        # Grading the part
        self.points = 0
        self.side = None  # Side information
        self.seconds = 0
        self.messages = []
        self.failed = False

    def fail(self):
        self.failed = True

    def is_basic(self):
        return self.grade_func is not None and self.basic

    def is_hidden(self):
        return self.grade_func is not None and not self.basic

    def is_auto(self):
        return self.grade_func is not None

    def is_manual(self):
        return self.grade_func is None


class Grader:
    def __init__(self, args=None):
        if args is None:
            args = sys.argv
        self.parts = []  # Parts (to be added)
        self.total_points = 0
        self.parse_args(args)

    def parse_args(self, args):
        self.parser = argparse.ArgumentParser(description='Grader')
        self.parser.add_argument('--mode', metavar='M', type=str, default=AUTO_MODE,
                            help='Mode: %s|%s|%s (default: %s)' % (BASIC_MODE, AUTO_MODE, ALL_MODE, AUTO_MODE))
        self.parser.add_argument('--part', metavar='P', type=str,
                            help='Only grade this part (e.g. 1a-1-basic)')
        self.parser.add_argument('--score_output', metavar='O', type=str, default=None,
                            help='File to output score json')
        self.parser.add_argument('--load_submission_module', metavar='L', type=str, default='submission',
                            help='Name of submission module to load')

        self.args = self.parser.parse_args(args[1:])
        self.mode = self.args.mode
        self.selectedPartName = self.args.part

    def add_basic_part(self, number, grade_func, max_points, max_seconds=default_max_seconds, description=''):
        self.parts.append(Part(number, grade_func, max_points, max_seconds, False, description, True))
        self.total_points += max_points

    def add_hidden_part(self, number, grade_func, max_points, max_seconds=default_max_seconds, description=''):
        self.parts.append(Part(number, grade_func, max_points, max_seconds, False, description, False))
        self.total_points += max_points

    def add_manual_part(self, number, max_points, description='', extra_credit=False):
        self.parts.append(Part(number, None, max_points, None, extra_credit, description, True))

    def load(self, module_name):
        return __import__(module_name)

    def is_selected_part(self, part):
        return self.selectedPartName is None or self.selectedPartName == part.number

    def grade_part(self, part):
        is_windows = sys.platform == "win32"
        
        # Only set alarm if not on Windows
        if not is_windows:
            signal.alarm(part.max_seconds)
        
        time_start = datetime.datetime.now()
        try:
            TimeoutFunction(part.grade_func, part.max_seconds)()
            part.points = part.max_points
        except TimeoutFunctionException:
            # Our code
            part.messages.append('Timed out after %d seconds.' % part.max_seconds)
            part.fail()
        except Exception as e:
            # Student's code
            part.messages.append('Exception: %s: %s' % (e.__class__.__name__, e))
            # Filter out lines related to the grader itself
            formatted_trace = traceback.format_exc().split('\n')
            user_trace = [item for item in formatted_trace if not item.strip().endswith('graderUtil.py') and not item.strip().startswith('File "D:\\USER\\Compressed\\route\\graderUtil.py')]
            part.messages += user_trace
            part.fail()
        finally:
            time_end = datetime.datetime.now()
            part.seconds = (time_end - time_start).total_seconds()
            
            # Only clear alarm if not on Windows
            if not is_windows:
                signal.alarm(0)
            
            # Garbage collect to reduce memory usage
            gc.collect()

    def require_is_true(self, condition, message="Assertion failed"):
        """Assert that a condition is true."""
        if not condition:
            raise Exception(message)

    def require_is_equal(self, expected, actual, tolerance=TOLERANCE, message=None):
        """Assert that two values are equal (with tolerance for floats)."""
        if not is_equal(expected, actual, tolerance):
            if message is None:
                message = f"Expected {expected}, but got {actual}"
            raise Exception(message)

    def require_is_false(self, condition, message="Assertion failed"):
        """Assert that a condition is false."""
        if condition:
            raise Exception(message)

    def grade(self):
        print('=' * 30)
        print('Starting grading')
        print('Mode: %s' % self.mode)
        print('Selected part: %s' % (self.selectedPartName if self.selectedPartName else 'all'))
        print('=' * 30)

        total_points = 0
        max_points = 0
        for i, part in enumerate(self.parts):
            if not self.is_selected_part(part):
                continue
            
            if part.is_manual():
                if self.mode == BASIC_MODE or self.mode == AUTO_MODE:
                    continue
                print('==> Part %s: %s (manual)' % (part.number, part.description))
                print('This part requires manual grading.')
            
            elif part.is_hidden():
                if self.mode == BASIC_MODE:
                    continue
                print('==> Part %s: %s (hidden)' % (part.number, part.description))
                self.grade_part(part)

            elif part.is_basic():
                print('==> Part %s: %s (basic)' % (part.number, part.description))
                self.grade_part(part)

            else:
                raise Exception('Unknown part type: %s' % part.number)

            if part.is_auto():
                print('    Points: %d/%d (%.2f seconds)' % (part.points, part.max_points, part.seconds))
                if part.messages:
                    print('    Messages:')
                    for message in part.messages:
                        print('      %s' % message)
                
                total_points += part.points
                max_points += part.max_points

        print('=' * 30)
        print('Total score (basic + hidden): %d/%d' % (total_points, max_points))
        print('=' * 30)

        # Output score json file
        if self.args.score_output:
            with open(self.args.score_output, 'w') as f:
                json.dump({
                    'parts': [{'name': part.number, 'score': part.points, 'max_score': part.max_points} for part in self.parts],
                    'total_score': total_points,
                    'max_total_score': max_points
                }, f, indent=2)