from util import manhattanDistance
from game import Directions
import random
import util
from typing import Any, DefaultDict, List, Set, Tuple

from game import Agent
from pacman import GameState



class ReflexAgent(Agent):
    """
    A reflex agent chooses an action at each choice point by examining
    its alternatives via a state evaluation function.

    The code below is provided as a guide.  You are welcome to change
    it in any way you see fit, so long as you don't touch our method
    headers.
    """

    def __init__(self):
        self.lastPositions = []
        self.dc = None

    def getAction(self, gameState: GameState):
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()

        # Choose one of the best actions
        scores = [self.evaluationFunction(
            gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(
            len(scores)) if scores[index] == bestScore]
        # Pick randomly among the best
        chosenIndex = random.choice(bestIndices)
        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState: GameState, action: str) -> float:
        # Useful information you can extract from a GameState (pacman.py)
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        newPos = successorGameState.getPacmanPosition()
        newFood = successorGameState.getFood()
        newGhostStates = successorGameState.getGhostStates()
        newScaredTimes = [
            ghostState.scaredTimer for ghostState in newGhostStates]

        score = successorGameState.getScore()
        foodList = newFood.asList()
        if not foodList:
            return float('inf')

        minFoodDist = min(util.manhattanDistance(newPos, f) for f in foodList)
        ghostPositions = [ghost.getPosition() for ghost in newGhostStates]
        minGhostDist = min(util.manhattanDistance(newPos, g) for g in ghostPositions) if ghostPositions else float('inf')
        ghostPenalty = 0
        if minGhostDist < 2:
            ghostPenalty = -500

        scaredGhosts = [g for g in newGhostStates if g.scaredTimer > 0]
        if scaredGhosts:
            minScaredDist = min(util.manhattanDistance(newPos, g.getPosition()) for g in scaredGhosts)
            if minScaredDist < 2:
                ghostPenalty += 200

        return score + 10.0 / (minFoodDist + 1) + ghostPenalty


def scoreEvaluationFunction(currentGameState: GameState):
    return currentGameState.getScore()


class MultiAgentSearchAgent(Agent):
    def __init__(self, evalFn='scoreEvaluationFunction', depth='2'):
        self.index = 0  # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

######################################################################################
# Problem 1b: implementing minimax

class MinimaxAgent(MultiAgentSearchAgent):
    def getAction(self, gameState: GameState) -> str:
        # BEGIN_YOUR_CODE
        def minimax(state: GameState, depth: int, agentIndex: int) -> float:
            if state.isWin() or state.isLose() or depth == self.depth * state.getNumAgents():
                return self.evaluationFunction(state)

            numAgents = state.getNumAgents()
            nextAgent = (agentIndex + 1) % numAgents
            nextDepth = depth + 1 if nextAgent == 0 else depth
            actions = state.getLegalActions(agentIndex)

            if agentIndex == 0:  # Pacman (max)
                return max(minimax(state.generateSuccessor(agentIndex, a), nextDepth, nextAgent) for a in actions)
            else:  # Ghosts (min)
                return min(minimax(state.generateSuccessor(agentIndex, a), nextDepth, nextAgent) for a in actions)

        legalMoves = gameState.getLegalActions(0)
        scores = [(minimax(gameState.generateSuccessor(0, a), 1, 1), a) for a in legalMoves]
        best_score = max(scores)[0]
        print(f"Minimax value: {best_score}")
        return max(scores)[1]
        # END_YOUR_CODE

######################################################################################
# Problem 2a: implementing alpha-beta

class AlphaBetaAgent(MultiAgentSearchAgent):
    def getAction(self, gameState: GameState) -> str:
        # BEGIN_YOUR_CODE
        def alphabeta(state: GameState, depth: int, agentIndex: int, alpha: float, beta: float) -> float:
            if state.isWin() or state.isLose() or depth == self.depth * state.getNumAgents():
                return self.evaluationFunction(state)

            numAgents = state.getNumAgents()
            nextAgent = (agentIndex + 1) % numAgents
            nextDepth = depth + 1 if nextAgent == 0 else depth
            actions = state.getLegalActions(agentIndex)

            if agentIndex == 0:  # Pacman (max)
                value = float('-inf')
                for a in actions:
                    value = max(value, alphabeta(state.generateSuccessor(agentIndex, a), nextDepth, nextAgent, alpha, beta))
                    if value > beta:
                        return value
                    alpha = max(alpha, value)
                return value
            else:  # Ghosts (min)
                value = float('inf')
                for a in actions:
                    value = min(value, alphabeta(state.generateSuccessor(agentIndex, a), nextDepth, nextAgent, alpha, beta))
                    if value < alpha:
                        return value
                    beta = min(beta, value)
                return value

        legalMoves = gameState.getLegalActions(0)
        bestScore, bestAction = float('-inf'), None
        alpha, beta = float('-inf'), float('inf')
        for a in legalMoves:
            score = alphabeta(gameState.generateSuccessor(0, a), 1, 1, alpha, beta)
            if score > bestScore:
                bestScore = score
                bestAction = a
            alpha = max(alpha, bestScore)
        return bestAction
        # END_YOUR_CODE

######################################################################################
# Problem 3b: implementing expectimax

class ExpectimaxAgent(MultiAgentSearchAgent):
    def getAction(self, gameState: GameState) -> str:
        # BEGIN_YOUR_CODE
        def expectimax(state: GameState, depth: int, agentIndex: int) -> float:
            if state.isWin() or state.isLose() or depth == self.depth * state.getNumAgents():
                return self.evaluationFunction(state)

            numAgents = state.getNumAgents()
            nextAgent = (agentIndex + 1) % numAgents
            nextDepth = depth + 1 if nextAgent == 0 else depth
            actions = state.getLegalActions(agentIndex)

            if agentIndex == 0:  # Pacman (max)
                return max(expectimax(state.generateSuccessor(agentIndex, a), nextDepth, nextAgent) for a in actions)
            else:  # Ghosts (expectation)
                return sum(expectimax(state.generateSuccessor(agentIndex, a), nextDepth, nextAgent) for a in actions) / len(actions)

        legalMoves = gameState.getLegalActions(0)
        scores = [(expectimax(gameState.generateSuccessor(0, a), 1, 1), a) for a in legalMoves]
        return max(scores)[1]
        # END_YOUR_CODE

######################################################################################
# Problem 4a (extra credit): creating a better evaluation function

def betterEvaluationFunction(currentGameState: GameState) -> float:
    # BEGIN_YOUR_CODE
    pacPos = currentGameState.getPacmanPosition()
    food = currentGameState.getFood().asList()
    ghosts = currentGameState.getGhostPositions()
    score = currentGameState.getScore()

    if not food:
        return float('inf')  # all food eaten

    minFoodDist = min(manhattanDistance(pacPos, f) for f in food)
    minGhostDist = min(manhattanDistance(pacPos, g) for g in ghosts) if ghosts else float('inf')
    ghostPenalty = 0
    if minGhostDist < 2:
        ghostPenalty = -500

    return score + 10.0 / (minFoodDist + 1) + ghostPenalty
    # END_YOUR_CODE

# Abbreviation
better = betterEvaluationFunction
