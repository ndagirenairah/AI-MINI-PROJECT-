import math, random
from collections import defaultdict
from typing import List, Callable, Tuple, Dict, Any, Optional, Iterable, Set
import gymnasium as gym
import numpy as np
import itertools # Added for fourierFeatureExtractor

import util
from util import ContinuousGymMDP, StateT, ActionT
from custom_mountain_car import CustomMountainCarEnv

############################################################
# Problem 3a
# Implementing Value Iteration on Number Line (from Problem 1)
def valueIteration(succAndRewardProb: Dict[Tuple[StateT, ActionT], List[Tuple[StateT, float, float]]], discount: float, epsilon: float = 1e-4):
    '''
    Given transition probabilities and rewards, computes and returns V and
    the optimal policy pi for each state.
    - succAndRewardProb: Dictionary mapping tuples of (state, action) to a list of (nextState, prob, reward) Tuples.
    - Returns: Dictionary mapping each state to an action.
    '''
    # Define a mapping from states to Set[Actions] so we can determine all the actions that can be taken from s.
    stateActions = defaultdict(set)
    for state, action in succAndRewardProb.keys():
        stateActions[state].add(action)

    def computeQ(V: Dict[StateT, float], state: StateT, action: ActionT) -> float:
        # Return Q(state, action) based on V(state)
        # BEGIN_YOUR_CODE
        q_value = 0.0
        # Iterate over (nextState, prob, reward) tuples
        for nextState, prob, reward in succAndRewardProb.get((state, action), []):
            # V[nextState] is 0 if not seen (handles terminal states)
            q_value += prob * (reward + discount * V[nextState])
        return q_value
        # END_YOUR_CODE

    def computePolicy(V: Dict[StateT, float]) -> Dict[StateT, ActionT]:
        # Return the policy given V.
        # Remember the policy for a state is the action that gives the greatest Q-value.
        # IMPORTANT: if multiple actions give the same Q-value, choose the largest action number for the policy. 
        # HINT: We only compute policies for states in stateActions.
        # BEGIN_YOUR_CODE
        pi = {}
        for state in stateActions:
            bestAction = None
            maxQ = -float('inf')
            
            # Sort actions in reverse (largest first) to handle tie-breaking correctly (largest action number)
            for action in sorted(list(stateActions[state]), reverse=True):
                q = computeQ(V, state, action)
                if q >= maxQ: 
                    maxQ = q
                    bestAction = action
            pi[state] = bestAction
        return pi
        # END_YOUR_CODE

    print('Running valueIteration...')
    V = defaultdict(float) # This will return 0 for states not seen (handles terminal states)
    numIters = 0
    while True:
        newV = defaultdict(float) # This will return 0 for states not seen (handles terminal states)
        max_change = 0.0
        
        # update V values using the computeQ function above.
        # repeat until the V values for all states do not change by more than epsilon.
        # BEGIN_YOUR_CODE
        for state in stateActions:
            maxQ = -float('inf')
            for action in stateActions[state]:
                maxQ = max(maxQ, computeQ(V, state, action))
            
            newV[state] = maxQ
            max_change = max(max_change, abs(newV[state] - V[state]))
            
        if max_change < epsilon:
            break
        # END_YOUR_CODE
        V = newV
        numIters += 1
    V_opt = V
    print(("valueIteration: %d iterations" % numIters))
    return computePolicy(V_opt)

def run_VI_over_numberLine(mdp):
   succAndRewardProb = defaultdict(list)
   for s in range(-mdp.n + 1, mdp.n):
       for action in mdp.actions:
           if action == 1:
               prob_forward = 0.2
               prob_backward = 0.8
           elif action == 2:
               prob_forward = 0.3
               prob_backward = 0.7
           next_s_forward = s + 1
           next_s_backward = s - 1
           for next_s, prob in [(next_s_forward, prob_forward), (next_s_backward, prob_backward)]:
               if next_s == mdp.n:
                   reward = mdp.rightReward
               elif next_s == -mdp.n:
                   reward = mdp.leftReward
               else:
                   reward = mdp.penalty
               succAndRewardProb[(s, action)].append((next_s, prob, reward))
   return valueIteration(succAndRewardProb, mdp.discount)

############################################################
# Problem 3b
# Model-Based Monte Carlo

# ... run_VI_over_numberLine (helper code) ...


class ModelBasedMonteCarlo(util.RLAlgorithm):
    def __init__(self, actions: List[ActionT], discount: float, calcValIterEvery: int = 10000,
                 explorationProb: float = 0.2,) -> None:
        self.actions = actions
        self.discount = discount
        self.calcValIterEvery = calcValIterEvery
        self.explorationProb = explorationProb
        self.numIters = 0

        # (state, action) -> {nextState -> ct} for all nextState
        self.tCounts = defaultdict(lambda: defaultdict(int))
        # (state, action) -> {nextState -> totalReward} for all nextState
        self.rTotal = defaultdict(lambda: defaultdict(float))

        self.pi = {} # Optimal policy for each state. state -> action

    # This algorithm will produce an action given a state.
    # Here we use the epsilon-greedy algorithm: with probability |explorationProb|, take a random action.
    # Should return random action if the given state is not in self.pi.
    # The input boolean |explore| indicates whether the RL algorithm is in train or test time. If it is false (test), we
    # should always follow the policy if available.
    # HINT: Use random.random() (not np.random()) to sample from the uniform distribution [0, 1]
    def getAction(self, state: StateT, explore: bool = True) -> ActionT:
        if explore:
            self.numIters += 1
        explorationProb = self.explorationProb
        if self.numIters < 2e4: # Always explore
            explorationProb = 1.0
        elif self.numIters > 1e6: # Lower the exploration probability by a logarithmic factor.
            explorationProb = explorationProb / math.log(self.numIters - 100000 + 1)
        # BEGIN_YOUR_CODE
        actions = self.actions
        
        if explore and random.random() < explorationProb:
            # Exploration: Choose a random action
            return random.choice(actions)
        
        # Exploitation: Follow the learned policy, or explore randomly if state not in policy
        if state in self.pi:
            return self.pi[state]
        else:
            # If state not in policy (i.e., not visited yet), explore randomly
            return random.choice(actions)
        # END_YOUR_CODE

    # We will call this function with (s, a, r, s'), which is used to update tCounts and rTotal.
    # For every self.calcValIterEvery steps, runs value iteration after estimating succAndRewardProb.
    def incorporateFeedback(self, state: StateT, action: ActionT, reward: int, nextState: StateT, terminal: bool):

        self.tCounts[(state, action)][nextState] += 1
        self.rTotal[(state, action)][nextState] += reward

        if self.numIters % self.calcValIterEvery == 0:
            # Estimate succAndRewardProb based on self.tCounts and self.rTotal.
            succAndRewardProb = defaultdict(list)
            # BEGIN_YOUR_CODE
            for (s, a), nextStateCounts in self.tCounts.items():
                total_count = sum(nextStateCounts.values())
                if total_count == 0: continue
                
                for s_prime, count in nextStateCounts.items():
                    prob = count / total_count
                    
                    # R(s, a, s') = (total reward of (s,a) -> s') / (counts of transition (s,a) -> s')
                    total_r = self.rTotal[(s, a)].get(s_prime, 0.0)
                    avg_reward = total_r / count
                    
                    succAndRewardProb[(s, a)].append((s_prime, prob, avg_reward))

            self.pi = valueIteration(succAndRewardProb, self.discount)
            # END_YOUR_CODE

############################################################
# Problem 4a
# Performs Tabular Q-learning. Read util.RLAlgorithm for more information.
class TabularQLearning(util.RLAlgorithm):
    def __init__(self, actions: List[ActionT], discount: float,
                 explorationProb: float = 0.2, initialQ: float = 0):
        '''
        - actions: the list of valid actions
        - discount: a number between 0 and 1, which determines the discount factor
        - explorationProb: the epsilon value indicating how frequently the policy returns a random action
        - intialQ: the value for intializing Q values.
        '''
        self.actions = actions
        self.discount = discount
        self.explorationProb = explorationProb
        self.Q = defaultdict(lambda: initialQ)
        self.numIters = 0

    # This algorithm will produce an action given a state.
    def getAction(self, state: StateT, explore: bool = True) -> ActionT:
        if explore:
            self.numIters += 1
        explorationProb = self.explorationProb
        if self.numIters < 2e4: # explore
            explorationProb = 1.0
        elif self.numIters > 1e5: # Lower the exploration probability by a logarithmic factor.
            explorationProb = explorationProb / math.log(self.numIters - 100000 + 1)
        # BEGIN_YOUR_CODE
        actions = self.actions
        
        if explore and random.random() < explorationProb:
            # Exploration: Choose a random action
            return random.choice(actions)
        
        # Exploitation: Choose action with max Q-value
        bestAction = None
        maxQ = -float('inf')

        for action in sorted(actions, reverse=True):
            q = self.Q[state, action]
            if q > maxQ:
                maxQ = q
                bestAction = action

        return bestAction if bestAction is not None else random.choice(actions)
        # END_YOUR_CODE

    # Call this function to get the step size to update the weights.
    def getStepSize(self) -> float:
        return 0.1

    # We will call this function with (s, a, r, s'), which you should use to update |Q|.
    def incorporateFeedback(self, state: StateT, action: ActionT, reward: float, nextState: StateT, terminal: bool) -> None:
        # BEGIN_YOUR_CODE
        alpha = self.getStepSize()
        currentQ = self.Q[state, action]
        
        if terminal:
            # If nextState is terminal, V(s') = 0
            maxQPrime = 0.0
        else:
            # Calculate max_{a'} Q(s', a')
            maxQPrime = -float('inf')
            for a_prime in self.actions:
                maxQPrime = max(maxQPrime, self.Q[nextState, a_prime])
        
        # Target = Reward + gamma * maxQPrime
        target = reward + self.discount * maxQPrime
        
        # Update Q: Q(s, a) <- Q(s, a) + alpha * (Target - Q(s, a))
        self.Q[state, action] = currentQ + alpha * (target - currentQ)
        # END_YOUR_CODE

############################################################
# Problem 4b: Fourier feature extractor

def fourierFeatureExtractor(
    state: StateT,
    maxCoeff: int = 5,
    scale: Optional[Iterable] = None
    ) -> np.ndarray:
    '''
    For state (x, y, z), maxCoeff 2, and scale [2, 1, 1], this should output (in any order):
    [1, cos(pi * 2x), cos(pi * y), cos(pi * z),
      cos(pi * (2x + y)), cos(pi * (2x + z)), cos(pi * (y + z)),
      cos(pi * (4x)), cos(pi * (2y)), cos(pi * (2z)),
      cos(pi*(4x + y)), cos(pi * (4x + z)), ..., cos(pi * (4x + 2y + 2z))]
    '''
    if scale is None:
        scale = np.ones_like(state)
    features = None

    # BEGIN_YOUR_CODE
    scale = np.array(scale)
    scaled_state = np.array(state) * scale
    d = len(state) # Dimensionality of the state
    
    # Generate coefficient vectors (c)
    # This creates all combinations of (c0, c1, ...) where c_i is in [0, maxCoeff]
    coefficients = np.array(list(itertools.product(range(maxCoeff + 1), repeat=d)))
    
    # Calculate dot product: c . scaled_state
    dotProduct = np.dot(coefficients, scaled_state)
    
    # Apply the Fourier basis function: cos(pi * dotProduct)
    features = np.cos(np.pi * dotProduct)
    # The first feature (c=(0,0,...)) will be cos(0)=1, serving as the bias term.
    # END_YOUR_CODE

    return features

############################################################
# Problem 4c: Q-learning with Function Approximation
# Performs Function Approximation Q-learning. Read util.RLAlgorithm for more information.
class FunctionApproxQLearning(util.RLAlgorithm):
    def __init__(self, featureDim: int, featureExtractor: Callable, actions: List[int],
                 discount: float, explorationProb=0.2):
        '''
        - featureDim: the dimensionality of the output of the feature extractor
        - featureExtractor: a function that takes a state and returns a numpy array representing the feature.
        - actions: the list of valid actions
        - discount: a number between 0 and 1, which determines the discount factor
        - explorationProb: the epsilon value indicating how frequently the policy returns a random action
        '''
        self.featureDim = featureDim
        self.featureExtractor = featureExtractor
        self.actions = actions
        self.discount = discount
        self.explorationProb = explorationProb
        self.W = np.random.standard_normal(size=(featureDim, len(actions)))
        self.numIters = 0

    def getQ(self, state: np.ndarray, action: int) -> float:
        # BEGIN_YOUR_CODE
        # Feature vector for state
        features = self.featureExtractor(state)
        
        # Weights for the given action: self.W[:, action]
        weights_for_action = self.W[:, action]
        
        # Q(s, a) = weights . features
        return np.dot(weights_for_action, features)
        # END_YOUR_CODE

    # This algorithm will produce an action given a state.
    def getAction(self, state: np.ndarray, explore: bool = True) -> int:
        if explore:
            self.numIters += 1
        explorationProb = self.explorationProb
        if self.numIters < 2e4: # Always explore
            explorationProb = 1.0
        elif self.numIters > 1e5: # Lower the exploration probability by a logarithmic factor.
            explorationProb = explorationProb / math.log(self.numIters - 100000 + 1)

        # BEGIN_YOUR_CODE
        actions = self.actions
        
        if explore and random.random() < explorationProb:
            # Exploration: Choose a random action
            return random.choice(actions)
        
        # Exploitation: Choose action with max Q-value
        bestAction = None
        maxQ = -float('inf')

        for action in sorted(actions, reverse=True):
            q = self.getQ(state, action)
            if q > maxQ:
                maxQ = q
                bestAction = action

        return bestAction if bestAction is not None else random.choice(actions)
        # END_YOUR_CODE

    # Call this function to get the step size to update the weights.
    def getStepSize(self) -> float:
        return 0.005 * (0.99)**(self.numIters / 500)

    # We will call this function with (s, a, r, s'), which you should use to update |weights|.
    def incorporateFeedback(self, state: np.ndarray, action: int, reward: float, nextState: np.ndarray, terminal: bool) -> None:
        # BEGIN_YOUR_CODE
        alpha = self.getStepSize()
        currentQ = self.getQ(state, action)
        
        if terminal:
            # If nextState is terminal, V(s') = 0
            maxQPrime = 0.0
        else:
            # Calculate max_{a'} Q(s', a')
            maxQPrime = -float('inf')
            for a_prime in self.actions:
                maxQPrime = max(maxQPrime, self.getQ(nextState, a_prime))
        
        # Target = Reward + gamma * maxQPrime
        target = reward + self.discount * maxQPrime
        
        # Error (difference): Target - Q(s, a)
        error = target - currentQ
        
        # Feature vector phi(s)
        features = self.featureExtractor(state)
        
        # Update weights for the specific action: W[:, a] <- W[:, a] + alpha * error * features
        self.W[:, action] += alpha * error * features
        # END_YOUR_CODE

############################################################
# Problem 5c: Constrained Q-learning

class ConstrainedQLearning(FunctionApproxQLearning):
    def __init__(self, featureDim: int, featureExtractor: Callable, actions: List[int],
                 discount: float, force: float, gravity: float,
                 max_speed: Optional[float] = None,
                 explorationProb=0.2):
        super().__init__(featureDim, featureExtractor, actions,
                             discount, explorationProb)
        self.force = force
        self.gravity = gravity
        self.max_speed = max_speed # Used as velocity_threshold

    # This algorithm will produce an action given a state.
    def getAction(self, state: np.ndarray, explore: bool = True) -> int:
        if explore:
            self.numIters += 1
        explorationProb = self.explorationProb
        if self.numIters < 2e4: # Always explore
            explorationProb = 1.0
        elif self.numIters > 1e5: # Lower the exploration probability by a logarithmic factor.
            explorationProb = explorationProb / math.log(self.numIters - 100000 + 1)

        # BEGIN_YOUR_CODE
        position, velocity = state[0], state[1]
        validActions = []
        
        # 1. Determine the set of valid actions (actions that lead to nextVelocity < velocity_threshold)
        for action in self.actions:
            # action indices: 0=Left (-force), 1=None (0), 2=Right (+force)
            force_applied = (action - 1) * self.force
            
            # gravity is cos(3 * position) * (-G)
            gravity_effect = np.cos(3 * position) * (-self.gravity)
            
            # velocity_{t+1} = velocity_t + force + gravity
            nextVelocity = velocity + force_applied + gravity_effect
            
            # Check the constraint: velocity_(t+1) < velocity_threshold (self.max_speed)
            if nextVelocity < self.max_speed:
                validActions.append(action)

        if not validActions:
            return None # Handle case where the set of valid actions is empty

        if explore and random.random() < explorationProb:
            # Exploration: Choose a random action from the VALID set
            return random.choice(validActions)
        else:
            # Exploitation: Choose action with max Q-value from the VALID set
            bestAction = None
            maxQ = -float('inf')

            for action in sorted(validActions, reverse=True):
                q = self.getQ(state, action)
                if q > maxQ:
                    maxQ = q
                    bestAction = action
            
            return bestAction
        # END_YOUR_CODE

############################################################
# This is helper code for comparing the predicted optimal
# actions for 2 MDPs with varying max speed constraints

mdp1 = util.ContinuousGymMDP("MountainCar-v0", discount=0.999, timeLimit=1000)
mdp2 = util.ContinuousGymMDP("MountainCar-v0", discount=0.999, timeLimit=1000)

def compare_MDP_Strategies(mdp_unconstrained, mdp_constrained):
    featureExtractor = lambda s: fourierFeatureExtractor(s, maxCoeff=5, scale=[1, 15])

    # Unconstrained Q-learning
    rl_unconstrained = FunctionApproxQLearning(
        featureDim=36,
        featureExtractor=featureExtractor,
        actions=mdp_unconstrained.actions,
        discount=mdp_unconstrained.discount,
        explorationProb=0.2
    )
    rewards_unconstrained = util.simulate(mdp_unconstrained, rl_unconstrained, numTrials=10, train=True)
    print("Unconstrained average reward:", sum(rewards_unconstrained) / len(rewards_unconstrained))

    # Constrained Q-learning
    rl_constrained = ConstrainedQLearning(
        featureDim=36,
        featureExtractor=featureExtractor,
        actions=mdp_constrained.actions,
        discount=mdp_constrained.discount,
        force=0.001,
        gravity=0.0025,
        max_speed=0.07,  # Set a default max_speed for constrained MDP
        explorationProb=0.2
    )
    rewards_constrained = util.simulate(mdp_constrained, rl_constrained, numTrials=10, train=True)
    print("Constrained average reward:", sum(rewards_constrained) / len(rewards_constrained))