// Sentiment Analysis JavaScript Implementation

let weights = {};

// Load weights from JSON file
async function loadWeights() {
  try {
    const response = await fetch("weights.json");
    weights = await response.json();
    console.log("Weights loaded:", Object.keys(weights).length, "features");
  } catch (error) {
    console.error("Error loading weights:", error);
  }
}

// Extract word features from text
function extractWordFeatures(text) {
  const wordCount = {};
  const words = text.toLowerCase().split(/\s+/);
  words.forEach((word) => {
    if (word.trim()) {
      wordCount[word] = (wordCount[word] || 0) + 1;
    }
  });
  return wordCount;
}

// Dot product of two vectors
function dotProduct(vec1, vec2) {
  let sum = 0;
  for (const key in vec1) {
    sum += vec1[key] * (vec2[key] || 0);
  }
  return sum;
}

// Predict sentiment
function predictSentiment(text) {
  const features = extractWordFeatures(text);
  const score = dotProduct(features, weights);
  return score >= 0 ? "Positive" : "Negative";
}

// Initialize when page loads
document.addEventListener("DOMContentLoaded", function () {
  loadWeights();

  const analyzeBtn = document.getElementById("analyze-btn");
  const reviewInput = document.getElementById("review-input");
  const sentimentOutput = document.getElementById("sentiment-output");

  analyzeBtn.addEventListener("click", function () {
    const review = reviewInput.value.trim();
    if (review) {
      const sentiment = predictSentiment(review);
      sentimentOutput.textContent = `Sentiment: ${sentiment}`;
      sentimentOutput.style.color = sentiment === "Positive" ? "green" : "red";
    } else {
      sentimentOutput.textContent = "Please enter a review to analyze.";
      sentimentOutput.style.color = "black";
    }
  });
});
