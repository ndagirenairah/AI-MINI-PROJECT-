#!/usr/bin/python

import random
from typing import Callable, Dict, List, Tuple, TypeVar
from collections import defaultdict

from util import *

FeatureVector = Dict[str, int]
WeightVector = Dict[str, float]
Example = Tuple[FeatureVector, int]

############################################################
# Problem 3a: feature extraction

def extractWordFeatures(x: str) -> dict:
    word_count = defaultdict(int)
    for word in x.split():
        word_count[word] += 1
    return dict(word_count)

############################################################
# Problem 3b: stochastic gradient descent

T = TypeVar('T')

def learnPredictor(trainExamples: List[Tuple[T, int]],
                   validationExamples: List[Tuple[T, int]],
                   featureExtractor: Callable[[T], FeatureVector],
                   numEpochs: int, eta: float) -> WeightVector:
    weights = {}  # feature => weight
    for epoch in range(numEpochs):
        for x, y in trainExamples:
            phi = featureExtractor(x)
            score = dotProduct(weights, phi)
            if y * score < 1:
                increment(weights, eta * y, phi)
        trainError = evaluatePredictor(
            trainExamples, lambda x: 1 if dotProduct(featureExtractor(x), weights) >= 0 else -1)
        validationError = evaluatePredictor(
            validationExamples, lambda x: 1 if dotProduct(featureExtractor(x), weights) >= 0 else -1)
        print(f"Epoch {epoch+1}: train error = {trainError}, validation error = {validationError}")
    return weights

############################################################
# Problem 3c: generate test case

def generateDataset(numExamples: int, weights: WeightVector) -> List[Example]:
    random.seed(42)
    def generateExample() -> Tuple[Dict[str, int], int]:
        phi = {}
        for feature in random.sample(list(weights.keys()), k=len(weights)//2 or 1):
            phi[feature] = random.randint(1, 5)
        score = dotProduct(weights, phi)
        y = 1 if score >= 0 else -1
        return phi, y
    return [generateExample() for _ in range(numExamples)]

############################################################
# Problem 3d: character features

def extractCharacterFeatures(n: int) -> Callable[[str], FeatureVector]:
    def extract(x: str) -> Dict[str, int]:
        x = x.replace(" ", "")
        features = defaultdict(int)
        for i in range(len(x) - n + 1):
            ngram = x[i:i+n]
            features[ngram] += 1
        return dict(features)
    return extract

############################################################
# Problem 5: k-means - OPTIMIZED VERSION

def kmeans(examples: List[Dict[str, float]], K: int,
            maxEpochs: int) -> Tuple[List, List, float]:

    random.seed(42)  # Ensure deterministic behavior for stability tests

    # Precompute squared norms of all examples for efficiency
    example_norms = [sum(val * val for val in ex.values()) for ex in examples]

    # Initialize centers randomly
    centers = [dict(ex) for ex in random.sample(examples, K)]
    assignments = [0] * len(examples)
    
    for epoch in range(maxEpochs):
        # Precompute center norms
        center_norms = [sum(val * val for val in center.values()) for center in centers]
        
        # Assignment step - use ||x - c||^2 = ||x||^2 + ||c||^2 - 2*x·c
        new_assignments = []
        for i, x in enumerate(examples):
            min_distance_sq = float('inf')
            best_cluster = 0
            
            for j, center in enumerate(centers):
                # Use precomputed norms and dot product
                # distance^2 = ||x||^2 + ||center||^2 - 2*(x · center)
                dot_prod = dotProduct(x, center)
                distance_sq = example_norms[i] + center_norms[j] - 2 * dot_prod
                
                if distance_sq < min_distance_sq:
                    min_distance_sq = distance_sq
                    best_cluster = j
            
            new_assignments.append(best_cluster)
        
        # Check for convergence
        if new_assignments == assignments:
            break
        
        assignments = new_assignments
        
        # Update centers efficiently using sums and counts
        sums = [defaultdict(float) for _ in range(K)]
        counts = [0] * K
        for i, j in enumerate(assignments):
            for f, v in examples[i].items():
                sums[j][f] += v
            counts[j] += 1

        new_centers = []
        for j in range(K):
            if counts[j] > 0:
                new_centers.append({f: s / counts[j] for f, s in sums[j].items()})
            else:
                # Empty cluster - reinitialize to random example
                new_centers.append(dict(random.choice(examples)))

        centers = new_centers
        # Precompute new center norms
        center_norms = [sum(val * val for val in center.values()) for center in centers]
    
    # Calculate final loss using optimized distance calculation
    loss = 0
    for i in range(len(examples)):
        x = examples[i]
        center = centers[assignments[i]]
        
        # Compute center norm for this final calculation
        center_norm_sq = sum(val * val for val in center.values())
        dot_prod = dotProduct(x, center)
        distance_sq = example_norms[i] + center_norm_sq - 2 * dot_prod
        loss += distance_sq
    
    return centers, assignments, loss

############################################################
# TEST EXAMPLES

if __name__ == "__main__":
    # Test extractWordFeatures
    print("Word features:", extractWordFeatures("I am what I am"))
    
    # Train on actual data
    trainExamples = readExamples('polarity.train')
    devExamples = readExamples('polarity.dev')
    weights = learnPredictor(trainExamples, devExamples, extractWordFeatures, numEpochs=20, eta=0.01)
    print("Learned weights:", len(weights), "features")

    # Test generateDataset
    sample_weights = {'I': 1.0, 'am': 0.5, 'happy': 1.5, 'sad': -1.0}
    dataset = generateDataset(5, sample_weights)
    print("Generated dataset:", dataset)

    # Test extractCharacterFeatures
    char_features = extractCharacterFeatures(2)
    print("Character features of 'I like tacos':", char_features("I like tacos"))

    # Test kmeans
    examples = [{'a':1, 'b':2}, {'a':2, 'b':1}, {'a':10, 'b':10}]
    centers, assignments, loss = kmeans(examples, K=2, maxEpochs=10)
    print("K-means centers:", centers)
    print("Assignments:", assignments)
    print("Loss:", loss)