'''
Licensing Information: Please do not distribute or publish solutions to this
project. You are free to use and extend Driverless Car for educational
purposes. The Driverless Car project was developed at Stanford, primarily by
Chris Piech (piech@cs.stanford.edu). It was inspired by the Pacman projects.
'''

# MANUAL PARTS ANSWERS (Written responses as per assignment requirements)
# These are included as comments in submission.py to maximize points, as per lecturer's instructions.

# Problem 1a [2 points]: Bayesian Network for Emission Probabilities
# Draw a Bayesian Network describing the distribution of variables C, D1, D2, D3, a1, a2, a3.
# Shade the variables that have been observed after time step t=3, and leave variables that are unobserved unshaded.
# Nodes: C (unobserved), D1 (observed), D2 (observed), D3 (observed), a1 (observed), a2 (observed), a3 (observed).
# Arrows: C -> D1, C -> D2, C -> D3 (since D_t depends on C and a_t, but a_t is observed).
# Shaded: D1, D2, D3, a1, a2, a3. Unshaded: C.

# Problem 1b [4 points]: Expression for the joint probability P(C=c, D1=d1, D2=d2, D3=d3)
# P(C=c, D1=d1, D2=d2, D3=d3) = P(C=c) * P(D1=d1 | C=c, a1) * P(D2=d2 | C=c, a2) * P(D3=d3 | C=c, a3)
# Since a1, a2, a3 are known with probability 1, and D_t ~ N(||a_t - C||_2, σ^2).

# Problem 2a [2 points]: Bayesian Network for Transition Probabilities
# Draw a Bayesian Network describing the distribution of variables C1, C2, C3, D1, D2, D3, a1, a2, a3.
# Shade the variables that have been observed after time step t=3, and leave variables that are unobserved unshaded.
# Nodes: C1 (unobserved), C2 (unobserved), C3 (unobserved), D1 (observed), D2 (observed), D3 (observed), a1 (observed), a2 (observed), a3 (observed).
# Arrows: C1 -> C2, C2 -> C3, C1 -> D1, C2 -> D2, C3 -> D3.
# Shaded: D1, D2, D3, a1, a2, a3. Unshaded: C1, C2, C3.

# Problem 2b [4 points]: Expression for the joint probability P(C1=c1, C2=c2, C3=c3, D1=d1, D2=d2, D3=d3)
# P(C1=c1, C2=c2, C3=c3, D1=d1, D2=d2, D3=d3) = P(C1=c1) * P(C2=c2 | C1=c1) * P(C3=c3 | C2=c2) * P(D1=d1 | C1=c1, a1) * P(D2=d2 | C2=c2, a2) * P(D3=d3 | C3=c3, a3)
# Since a1, a2, a3 are known.

# Problem 3a [5 points]: Conditional probability p(C11=c11, C12=c12 | E1=e1) for K=2, T=1
# p(C11=c11, C12=c12 | E1=e1) ∝ p(c11) * p(c12) * [p_N(e1[0]; ||a1 - c11||_2, σ^2) * p_N(e1[1]; ||a1 - c12||_2, σ^2) + p_N(e1[0]; ||a1 - c12||_2, σ^2) * p_N(e1[1]; ||a1 - c11||_2, σ^2)]
# Where E1 = [e1[0], e1[1]] is the unordered set of distances.
# This accounts for the two possible assignments of distances to cars.

# Problem 3b [4 points]: Number of assignments for maximum p(C11=..., C1K=... | E1=e1) is at least K!
# Since priors are the same for all cars, the maximum probability occurs for all permutations of car assignments to distances.
# With K distinct distances and unique car locations, there are K! ways to assign cars to distances that yield the same maximum probability,
# because the likelihood terms are symmetric under permutation when priors are identical.

# Problem 4a [3 points]: Misuse of camera sensor data in self-driving cars
# Camera sensors collect visual data including faces and license plates, which could be misused for surveillance, tracking individuals without consent, or enabling targeted attacks.
# To preempt misuse, implement data anonymization (e.g., blurring faces), limit data retention to necessary periods, and use federated learning to train models without centralizing data.
# Additionally, incorporate privacy-by-design principles and conduct regular audits for ethical compliance.

# Problem 4c [2 points]: Guarding against sensor deception
# Use redundancy with multiple sensors (e.g., combine microphone with LIDAR or radar) to cross-verify readings and detect inconsistencies from deception attacks.

# Problem 4d [2 points]: Particle filtering simulation vs. exact inference
# In particle filtering, the belief cloud is more dispersed and approximate compared to exact inference's precise probability distribution.
# This is because particle filtering uses Monte Carlo sampling, which is efficient but introduces variance and approximation errors, unlike exact inference's full enumeration.

# Problem 4e [2 points]: Privacy-accuracy trade-off in on-device particle filtering
# Prioritize privacy by keeping data on-device to prevent breaches, as accuracy loss is acceptable if safety is maintained through conservative driving (e.g., slowing down in uncertain areas).
# Evaluate via metrics like collision rates, privacy leakage scores, and user surveys on trust.
# If accuracy drops too low, supplement with occasional cloud-based refinements for critical scenarios.

# Problem 4f [2 points]: Adversarial attack on camera-based autonomous vehicle
# Adversarial attack: Perturbed images (e.g., stickers on signs) to confuse object detection.
# Impact: Vehicle misclassifies stop signs as yield, leading to accidents.
# Mitigation: Adversarial training on perturbed datasets and real-time anomaly detection using multiple modalities.

import collections
import math
import random
import util
from engine.const import Const
from util import Belief
'''
Licensing Information: Please do not distribute or publish solutions to this
project. You are free to use and extend Driverless Car for educational
purposes. The Driverless Car project was developed at Stanford, primarily by
Chris Piech (piech@cs.stanford.edu). It was inspired by the Pacman projects.
'''
import collections
import math
import random
import util
from engine.const import Const
from util import Belief


class ExactInference:
    """ 
    Maintain and update a belief distribution over the probability of a car
    being in a tile using exact updates (correct, but slow times).
    """

    def __init__(self, numRows: int, numCols: int):
        """
        Constructor that initializes an ExactInference object which has
        numRows x numCols number of tiles.
        """
        self.skipElapse = False  ### ONLY USED BY GRADER.PY in case problem 2 has not been completed
        # util.Belief is a class (constructor) that represents the belief for a single
        # inference state of a single car (see util.py).
        self.belief = util.Belief(numRows, numCols)
        self.transProb = util.loadTransProb()

    ##################################################################################
    # Problem 1:
    # Function: Observe (update the probabilities based on an observation)
    # -----------------
    ##################################################################################

    def observe(self, agentX: int, agentY: int, observedDist: float) -> None:
        # BEGIN_YOUR_CODE
        # Fix for AttributeError: 'Belief' object has no attribute 'copy'
        # Create a new belief object initialized to zero
        newBelief = util.Belief(self.belief.getNumRows(), self.belief.getNumCols())
        
        for r in range(self.belief.getNumRows()):
            for c in range(self.belief.getNumCols()):
                current_belief = self.belief.getProb(r, c)
                
                # 1. Convert tile (r, c) to coordinates (carX, carY)
                carX = util.colToX(c)
                carY = util.rowToY(r)
                
                # 2. Calculate the expected (true) distance: ||a_t - C_t||_2
                true_dist = math.sqrt((agentX - carX)**2 + (agentY - carY)**2)
                
                # 3. Calculate the likelihood (emission probability): p(d_t | C_t=c)
                # We use util.pdf(mean, std, value)
                likelihood = util.pdf(true_dist, Const.SONAR_STD, observedDist)
                
                # 4. Apply Bayes' Rule (Unnormalized): P(C_t|d_{1:t}) \propto P(C_t|d_{1:t-1}) * p(d_t|C_t)
                new_prob = current_belief * likelihood
                newBelief.setProb(r, c, new_prob)
                
        self.belief = newBelief
        self.belief.normalize()
        # END_YOUR_CODE

    ##################################################################################
    # Problem 2:
    # Function: Elapse Time (propose a new belief distribution based on a learned transition model)
    # ---------------------
    ##################################################################################
    def elapseTime(self) -> None:
        if self.skipElapse: ### ONLY FOR THE GRADER TO USE IN Problem 1
            return
        # BEGIN_YOUR_CODE
        # Fix for AttributeError: 'Belief' object has no attribute 'copy'
        # Create a new belief object initialized to zero
        newBelief = util.Belief(self.belief.getNumRows(), self.belief.getNumCols(), value=0.0)

        # We update the belief using the recurrence:
        # P(C_{t+1}=c_{t+1}|d_{1:t}) = \sum_{c_t} P(C_t=c_t|d_{1:t}) * p(c_{t+1}|c_t)

        for (oldTile, newTile), prob in sorted(self.transProb.items()):
            # Get the probability of the car being at the old tile
            oldR, oldC = oldTile

            # P(C_t=c_t | d_{1:t}) - The current belief of being at oldTile
            prob_old = self.belief.getProb(oldR, oldC)

            # P(C_t=c_t | d_{1:t}) * p(c_{t+1} | c_t)
            prob_update = prob_old * prob

            # Sum this probability contribution to newTile (c_{t+1})
            newR, newC = newTile
            newBelief.addProb(newR, newC, prob_update)

        self.belief = newBelief
        self.belief.normalize() # Ensure probabilities sum exactly to 1
        # END_YOUR_CODE

    def getBelief(self) -> Belief:
        """
        Returns your belief of the probability that the car is in each tile. Your
        belief probabilities should sum to 1.
        """
        return self.belief


class ExactInferenceWithSensorDeception(ExactInference):
    """
    Same as ExactInference except with sensor deception attack represented in the
    observation function.
    """

    def __init__(self, numRows: int, numCols: int, skewness: float = 0.5):
        """
        Constructor that initializes an ExactInference object which has
        numRows x numCols number of tiles, as well as a skewness factor
        used to calculate the skewed observed distance distribution.
        """
        super().__init__(numRows, numCols)
        self.skewness = skewness

    ##################################################################################
    # Problem 4:
    # Function: Observe with sensor deception (update the probabilities based on an observation)
    # -----------------
    ##################################################################################

    def observe(self, agentX: int, agentY: int, observedDist: float) -> None:
        # BEGIN_YOUR_CODE
        # The transformation from the prompt is:
        # D_t_' = 1/(1+skewness**2) * D_t + sqrt(2 * (1/(1+skewness**2)))
        
        factor_base = 1.0 / (1.0 + self.skewness**2)
        
        # Calculate the new, deceived observed distance
        # D_t = observedDist
        deceivedDist = factor_base * observedDist + math.sqrt(2 * factor_base) 
        
        # We cannot use super().observe() if ExactInference.observe was also broken 
        # due to the 'copy' error. However, assuming the parent's logic is now 
        # fixed (as shown above), we can call it.
        # This calls the corrected ExactInference.observe method with the deceived distance.
        super().observe(agentX, agentY, deceivedDist)
        # END_YOUR_CODE

    def elapseTime(self) -> None:
        super().elapseTime()

    def getBelief(self) -> Belief:
        return super().getBelief()